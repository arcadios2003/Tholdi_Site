<SCRIPT LANGUAGE="JavaScript">
/**
 * Lister les départements d'une région avec un objet
 * XMLHTTPRequest.
 */
/* Création de la variable globale qui contiendra l'objet XHR */
var requete = null;
var requete1=null;
/**
 * Fonction privée qui va créer un objet XHR.
 * Cette fonction initialisera la valeur dans la variable globale définie
 * ci-dessus.
 */
function creerRequete()
{

    try{
        //On tente de créer un objet XmlHTTPRequest 
   
        requete = new XMLHttpRequest();
        requete1 = new XMLHttpRequest();
    }catch (microsoft)
    {
        /* Microsoft utilisant une autre technique, on essays de créer un objet ActiveX */
        try{
            requete = new ActiveXObject('Msxml2.XMLHTTP');
            requete1 = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch(autremicrosoft)
        {
            /* La première méthode a échoué, on en teste une seconde */
            try
            {
                requete = new ActiveXObject('Microsoft.XMLHTTP');
                requete1 = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch(echec)
            {
                /* À ce stade, aucune méthode ne fonctionne... mettez donc votre navigateur à jour ;) */
                requete = null;
            }
        }
    }
    if(requete == null)
    {
        alert('Impossible de créer l\'objet requête,\nVotre navigateur ne semble pas supporter les object XMLHttpRequest.');
    }
}
/**
 * Fonction privée qui va mettre à jour l'affichage de la page.
 */
function actualiserPays(nb)
{
    var listePays = requete.responseText;
    if(nb==1){
    var blocListe = document.getElementById('blocPaysD');
    }else{
     var blocListe = document.getElementById('blocPaysA');
    }
    blocListe.innerHTML = listePays;
}

/**
 * Fonction publique appelée par la page affichée.
 * Cette fonction va initialiser la création de l'objet XHR puis appeler
 * le code serveur afin de récupérer les données à modifier dans la page.
 */
function getPays(idr,nb,lng)
{ 
    /* Si il n'y a pas d'identifiant de région, on fait disparaître la seconde liste au cas où elle serait affichée */
    if(idr == '-1')
    {
        if(nb==1){
         document.getElementById('blocPaysD').innerHTML = '';
         }else{
         document.getElementById('blocPaysA').innerHTML = '';
         }       
        
    }
    else
    {
        /* À cet endroit précis, on peut faire apparaître un message d'attente */
        if (nb==1){
                var blocListe = document.getElementById('blocPaysD');
                }
                else{
                    var blocListe = document.getElementById('blocPaysA');
                    }
                    
          if(lng==1){          
                blocListe.innerHTML = "Traitement en cours, veuillez patienter...";
          }else{
                blocListe.innerHTML = "Processing, please wait ...";
          }
          /* On crée l'objet XHR */
        creerRequete();
        /* Définition du fichier de traitement */
        var url = 'Include/Resa/Pays.php?idr='+ idr+"&nb="+ nb+"&lng="+lng;
        /* Envoi de la requête à la page de traitement */
        requete.open('GET', url, true);
        /* On surveille le changement d'état de la requête qui va passer successivement de 1 à 4 */
        requete.onreadystatechange = function()
        {
            /* Lorsque l'état est à 4 */
            if(requete.readyState == 4)
            {
                /* Si on a un statut à 200 */
                if(requete.status == 200)
                {
                    /* Mise à jour de l'affichage, on appelle la fonction apropriée */
                    actualiserPays(nb);
                }
            }
        };
        requete.send(null);
    }
}



/**
 * Fonction privée qui va mettre à jour l'affichage de la page.
 */
function actualiserPort(nb)
{
    var listePort = requete1.responseText;
    if(nb==1){
        var blocListe1 = document.getElementById('blocPortD');
    }else{
        var blocListe1 = document.getElementById('blocPortA');
                                    }
    blocListe1.innerHTML = listePort;
}

/**
 * Fonction publique appelée par la page affichée.
 * Cette fonction va initialiser la création de l'objet XHR puis appeler
 * le code serveur afin de récupérer les données à modifier dans la page.
 */
function getPort(idr,val,lng)
{
    /* Si il n'y a pas d'identifiant de région, on fait disparaître la seconde liste au cas où elle serait affichée */
    if(idr == -1)
    {
        if (val==1)
        {
            document.getElementById('blocPortD').innerHTML = '';
        }
        else{
            document.getElementById('blocPortA').innerHTML = '';
        }
    }
    else
    {
        /* À cet endroit précis, on peut faire apparaître un message d'attente */
        if (val==1){
            var blocListe1 = document.getElementById('blocPortD');
        }else{
            var blocListe1 = document.getElementById('blocPortA');
        }
       /* if(lng==1){          
             //   blocListe.innerHTML = "Traitement en cours, veuillez patienter...";
          }else{
               // blocListe.innerHTML = "Processing, please wait ...";
          }*/
                                            /* On crée l'objet XHR */
        creerRequete();
        /* Définition du fichier de traitement */
        var url = 'Include/Resa/Port.php?idr1='+ idr+'&nb1='+val+'&lng1='+lng;
        /* Envoi de la requête à la page de traitement */
        requete1.open('GET', url, true);
        /* On surveille le changement d'état de la requête qui va passer successivement de 1 à 4 */
        requete1.onreadystatechange = function()
        {
            /* Lorsque l'état est à 4 */
            if(requete1.readyState == 4)
            {
                /* Si on a un statut à 200 */
                if(requete1.status == 200)
                {
                    /* Mise à jour de l'affichage, on appelle la fonction apropriée */
                    actualiserPort(val);
                }
            }
        };
        requete1.send(null);
    }
}
function actualisertaille(nb)
{
    var listePort = requete1.responseText;
    
    var blocListe1 = document.getElementById('taille'+nb);
    blocListe1.innerHTML = listePort;
}

/**
 * Fonction publique appelée par la page affichée.
 * Cette fonction va initialiser la création de l'objet XHR puis appeler
 * le code serveur afin de récupérer les données à modifier dans la page.
 */
function gettaille(idr,nb,lng)
{
    /* Si il n'y a pas d'identifiant de région, on fait disparaître la seconde liste au cas où elle serait affichée */
    if(idr == 'vide')
    {
        document.getElementById('taille'.nb).innerHTML = '';
    }
    else
    {
        /* À cet endroit précis, on peut faire apparaître un message d'attente */
        taille='taille'+nb
            var blocListe1 = document.getElementById(taille);
        if (lng==1){
            blocListe1.innerHTML = "Traitement en cours, veuillez patienter...";
        }else{
            blocListe1.innerHTML = "Processing, please wait ...";
        }/* On crée l'objet XHR */
        creerRequete();
        /* Définition du fichier de traitement */
        var url = 'Include/Resa/taille.php?idr='+ idr +'&nb='+ nb + '&lng=' + lng;
        /* Envoi de la requête à la page de traitement */
        requete1.open('GET', url, true);
        /* On surveille le changement d'état de la requête qui va passer successivement de 1 à 4 */
        requete1.onreadystatechange = function()
        {
            /* Lorsque l'état est à 4 */
            if(requete1.readyState == 4)
            {
                /* Si on a un statut à 200 */
                if(requete1.status == 200)
                {
                    /* Mise à jour de l'affichage, on appelle la fonction apropriée */
                    actualisertaille(nb);
                }
            }
        };
        requete1.send(null);
    }
}
 function getDate(strDate){
    day = strDate.substring(0,2);
    month = strDate.substring(3,5);
    year = strDate.substring(6,10);
    d = new Date();
    d.setDate(day);
    d.setMonth(month);
    d.setFullYear(year); 
    return d;  
}

function calculduree(){
    var blocdateA = document.getElementById('dateA').value;
    var blocdateD = document.getElementById('dateD').value;
    var dateA= getDate(blocdateA);
    var dateD= getDate(blocdateD);
    var NbJours = (dateA - dateD)/86400000;
    return(NbJours+1);
}


function actualiserprix(nb1,pays,ue,num){     


    var prixjour = requete1.responseText;
    
    var blocListe1 = document.getElementById('prix'+nb1);
    blocListe1.innerHTML = new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(prixjour);
    var blocListe2 = document.getElementById('total'+nb1);
    var blocListe2bis = document.getElementById('tot'+nb1);
    var tot= prixjour * nbjour* document.getElementById('qte-'+nb1).value;
    blocListe2.innerHTML = tot;
    blocListe2bis.innerHTML = new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(tot);
    var totgene=0;
    for(var i=1;i<=nb;i++){
        var valeur=document.getElementById('total'+i).firstChild.data.replace(/,/, '.');
       totgene =totgene + parseFloat(valeur) ;
    }
    var blocListe3 = document.getElementById('totalgeneral');
    blocListe3.innerHTML ="<input hidden name='totg-1' value='"+totgene+"'>"+new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(totgene);
    var blocListe4 = document.getElementById('tauxtva');
    var blocListe5 = document.getElementById('tva');
    var blocListe6 = document.getElementById('totalttc');
    var taux=0;
    if(pays=='FRA' || (ue==1)){
        var taux=0.2;
        
    }
    blocListe4.innerHTML =taux*100+" %";
    blocListe5.innerHTML ="<input hidden name='tva-1' value='"+totgene*taux+"'>"+  new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(totgene*taux);
    blocListe6.innerHTML = new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(totgene*(1+taux));
}        
      

        
function getprix(nb,lng,pays,ue,num)
{

   var codetype = document.getElementById('typeconteneur-'+nb).selectedIndex;
   var codetaille = document.getElementById('taille-'+nb).selectedIndex;
   
                   
   nbjour=calculduree();
   
   
    /* Si il n'y a pas d'identifiant de région, on fait disparaître la seconde liste au cas où elle serait affichée */
    if(nb == -1)
        document.getElementById('prix'.nb).innerHTML = '';
    else
    {
        /* À cet endroit précis, on peut faire apparaître un message d'attente */
        prix='prix'+nb;
        total='tot'+nb;
        var blocListe1 = document.getElementById(prix);
        var blocListe2= document.getElementById(total);
        var blocListe5 = document.getElementById('tva');
        var blocListe6 = document.getElementById('totalttc');
        var blocListe3 = document.getElementById('totalgeneral');
        blocListe1.innerHTML = "Calcul...";
        blocListe2.innerHTML = "Calcul...";
        blocListe3.innerHTML = "Calcul...";
        blocListe5.innerHTML = "Calcul...";
        blocListe6.innerHTML = "Calcul...";
        /* On crée l'objet XHR */
        creerRequete();
        /* Définition du fichier de traitement */
        idr=codetype.toString()+codetaille.toString();
        
        if (nbjour<90)
            var duree ='j';
        else
             if (nbjour<360)
                var duree ='t';
             else
                var duree ='a';
             
                
        var url = 'Include/Resa/Contneur.php?idr='+ idr +'&prix='+ duree + '&lng=' + lng;
      
        /* Envoi de la requête à la page de traitement */
        requete1.open('GET', url, true);
        /* On surveille le changement d'état de la requête qui va passer successivement de 1 à 4 */
        requete1.onreadystatechange = function()
        {        /* Lorsque l'état est à 4 */
            if(requete1.readyState == 4)
            
                /* Si on a un statut à 200 */
                if(requete1.status == 200)
                
                   
                    /* Mise à jour de l'affichage, on appelle la fonction apropriée */
                    actualiserprix(nb,pays,ue,num);
                
            
        };
        requete1.send(null);
    }
}



</script>