<SCRIPT LANGUAGE="JavaScript">

var requete = null;
var requete1 = null;

function creerRequete(){
	try {
		requete = new XMLHttpRequest();
		requete1 = new XMLHttpRequest();
	} catch (microsoft) {
		try {
			requete = new ActiveXObject('Msxml2.XMLHTTP');
			requete1 = new ActiveXObject('Msxm12.XMLHTTP');
		} catch (autremicrosoft){
			try {
				requete = new ActiveXObject('Microsoft.XMLHTTP');
				requete1 = new ActiveXObject('Microsoft.XMLHTTP');
			} catch (echec) {
				requete = null;
			}
		}
	}
	if(requete==null){
		alert('Impossible de créer l\'objet requête, \nVotre navigateur ne semble pas supporter les objet XMLHttpRequest');
	}
}

function actualiserPays(nb){
	var listePays = requete.responseText;
	if(nb==1){
		var blocListe = document.getElementById('blocPaysD');
	} else {
		var blocListe = document.getElementById('blocPaysA');
	}
	blocListe.innerHTML = listePays;
}

function getPays(idr,nb,lng) {
	if(idr =='-1'){
		if(nb==1){
			document.getElementById('blocPaysD').innerHTML = '';
		} else {
			document.getElementById('blocPaysA').innerHTML = '';
		}
	} else {
		if(nb==1) {
			var blocListe = document.getElementById('blocPaysD');
		} else {
			var blocListe = document.getElementById('blocPaysA');
		}
		if(lng==1) {
			blocListe.innerHTML = "Traitement en cours, veuillez patienter. . .";
		} else {
			blocListe.innerHTML = "Processing, please wait. . .";
		}
		creerRequete();
		var url = 'include/reservation/pays.php?idr='+ idr +"&nb="+ nb +"&lng=" + lng;
		requete.open('GET',url, true);
		requete.onreadystatechange = function() {
			if(requete.readyState == 4){
				if(requete.status == 200){
					actualiserPays(nb);
				}
			}
		};
		requete.send(null);
	}
}

function actualiserPort(nb){
	var lsitePort = requete1.responseText;
	if(nb==1){
		var blocListe1 = document.getElementById('blocPortD');
	} else {
		var blocListe1 = document.getElementById('blocPortA');
	}
	blocListe1.innerHTML = lsitePort;
}

function getPort(idr, val, lng){
	if(idr==1){
		if(val==1){
			document.getElementById('blocPortD').innerHTML = '';
		} else {
			document.getElementById('blocPortA').innerHTML = '';
		}
	} else {
		if(val==1){
			var blocListe1 = document.getElementById('blocPortD');
		} else {
			var blocListe1 = document.getElementById('blocPortA');
		}
		creerRequete();
		var url= 'include/reservation/port.php?idr1='+ idr + '&nb1='+ val + '&lng1=' + lng;
		requete1.open('GET', url, true);
		requete1.onreadystatechange = function(){
			if(requete1.readyState == 4) {
				if(requete1.status == 200) {
					actualiserPort(val);
				}
			}
		};
		requete1.send(null);
	}
}

function actualisertaille(nb){
	var listePort = requete1.responseText;
	var blocListe1 = document.getElementById('taille-'+nb);
	blocListe1.innerHTML = listePort;
}

function gettaille (idr, nb, lng){
	if(idr == 'vide') {
		document.getElementById('taille-'.nb).innerHTML = '';
	} else{
		taille = 'taille-' + nb;
		var blocListe1 = document.getElementById(taille);
		if (lng==1){
			blocListe1.innerHTML = 'Traitement en cours, veuillez patienter. . .';
		} else {
			blocListe1.innerHTML = 'Processing, please wait. . .';
		}
		creerRequete();
		var url = 'include/reservation/taille.php?idr='+ idr + '&nb='+ nb + '&lng='+ lng;
		requete1.open('GET', url, true);
		requete1.onreadystatechange = function(){
			if(requete1.readyState == 4){
				if(requete1.status == 200) {
					actualisertaille(nb);
				}
			}
		};
		requete1.send(null);
	}
}

function getDate(strDate) {
	day = strDate.substring(0,2);
	month = strDate.substring(3,5);
	year = strDate.substring(6,10);
	d = new Date();
	d.setDate(day);
	d.setMonth(month);
	d.setFullYear(year);
	return d;
}

function calculduree() {
	var blocdateA = document.getElementById('dateA').value;
	var blocdateD = document.getElementById('dateD').value;
	var dateA = getDate(blocdateA);
	var dateD = getDate(blocdateD);
	var NbJours = (dateA - dateD)/86400000;
	return(NbJours+1);
}

function actualiserprix(nbl,num){
	var prixjour = requete1.responseText;

	var blocListe1 = document.getElementById('prix'+nbl);
	blocListe1.innerHTML = new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(prixjour);
	var blocListe2 = document.getElementById('total'+nbl);

	var blocListe2bis = document.getElementById('tot'+nbl);
	var tot = prixjour * nbjour * document.getElementById('qte-'+nbl).value;
	blocListe2.innerHTML = tot;
	blocListe2bis.innerHTML = new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(tot);
	var totgene = 0;
	for (var i = 1; i <= nb; i++){
		var valeur=document.getElementById('total'+i).firstChild.data.replace(/,/,'.');
		totgene = totgene + parseFloat(valeur);
	}

	var blocListe3 = document.getElementById('totalgeneral');
	blocListe3.innerHTML = "<input hidden name='totg-1' value='"+totgene+"'>" + new Intl.NumberFormat("fr-FR", {style: 'currency', currency: "EUR"}).format(totgene);

	var blocListe4 = document.getElementById('tauxtva');
	var blocListe5 = document.getElementById('tva');
	var blocListe6 = document.getElementById('totalttc');
	var taux = 0.2;
	blocListe4.innerHTML = taux*100+" %";
	blocListe5.innerHTML = "<input hidden name='tva-1' value='"+ totgene*taux+"'>"+ new Intl.NumberFormat("fr-FR", {style: 'currency', currency: "EUR"}).format(totgene*taux);
	blocListe6.innerHTML = new Intl.NumberFormat("fr-FR", {style: "currency", currency: "EUR"}).format(totgene*(1+taux));
}

function getprix (nb, lng, num) {
	var codetype = document.getElementById('typeconteneur-'+nb).selectedIndex;
	var codetaille = document.getElementById('taille-'+nb).selectedIndex;

	nbjour = calculduree();

	if (nb== -1){
		document.getElementById('prix'.nb).innerHTML = '';
	} else {
		prix = 'prix' + nb;
		total = 'tot' + nb;
		var blocListe1 = document.getElementById(prix);
		var blocListe2 = document.getElementById(total);
		var blocListe5 = document.getElementById('tva');
		var blocListe6 = document.getElementById('totalttc');
		var blocListe3 = document.getElementById('totalgeneral');

		blocListe1.innerHTML = "Calcul ...";
		blocListe2.innerHTML = "Calcul ...";
		blocListe3.innerHTML = "Calcul ...";
		blocListe5.innerHTML = "Calcul ...";
		blocListe6.innerHTML = "Calcul ...";

		creerRequete();
		idr = codetype.toString()+codetaille.toString();

		if(nbjour<90){
			var duree = 'j';
		} else {
			if(nbjour<360){
				var duree = 't';
			} else {
				var duree = 'a';
			}
		}

		var url = 'include/reservation/Conteneur.php?idr=' + idr + '&prix='+ duree + '&lng=' + lng;

		requete1.open('GET', url, true);
		requete1.onreadystatechange = function() {
			if(requete1.readyState == 4) {
				if(requete1.status == 200) {
					actualiserprix(nb,num);
				}
			}
		};
		requete1.send(null);
	}
}

</SCRIPT>