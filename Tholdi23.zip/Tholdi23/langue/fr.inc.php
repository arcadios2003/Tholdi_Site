<?php
// FR-Français

/*---------------------------------------------
 Menuhaut.inc.php
---------------------------------------------*/
	define('TXT_ACUEIL_INDEX', 'Accueil');
	define('TXT_CONTENEUR', 'Nos Conteneurs');
	define('TXT_SERVICE', 'Nos Services');
	define('TXT_TARIFS', 'Nos Tarifs');

	// Pied.inc.php
	define('TXT_MENTION', 'Mention Légales');
	define('TXT_AGENCE', 'Nos Agences : ');

	//Accueil.inc.php
	define('TXT_PRESENTATION', 'La société THOLDI est spécialisée dans la gestion des conteneurs destinés au transport de marchandises.');
	define('TXT_PRESENTATION2', 'Elle intervient en qualité de prestataire de services pour le compte d\'entreprises de transports mais développe également depuis 2010 une activité de fret au travers de sa filiale "Eole".');
	define('TXT_PRESENTATION3', 'Les siège sociale de THOLDI est situé en région parisienne et ses zones d\' activités sont implantées dans plusieurs installations portuaires européennes.');

	//Tarif.inc.php
	define('TXT_TITRETARIFS', 'Nos Tarifs');
	define('TXT_TARIFJOUR', 'Jours');
	define('TXT_TARIFTRIM', 'Trimestre');
	define('TXT_TARIFAN', 'Année');
	define('TXT_TITRE', 'Nos Conteneurs');
	define('TXT_TYPE', 'Type de conteneurs');
	define('TXT_IMAGE', 'Image');
	define('TXT_TAILLES', 'Tailles');

	//Conteneurs.inc.php
	define('TXT_DIM', 'Ils existent dans différents dimensions :');
	define('TXT_TOUS','Tous');

	//AccueilServices.inc.php
	define('TXT_S1','Son activité principale consiste à: ');
	define('TXT_S2','Gérer le déchargement et la réception de conteneurs (contrôle de leur provenance et du transporteur maritime)');
	define('TXT_S3','Gérer le placement en zone de stockage temporaire');
	define('TXT_S4','Gérer le chargment des conteneurs sur les remorques de transport routier ou de transport ferroviaire');
	define('TXT_S5','Gérer le processus d\'acheminement de fret de "porte à porte"');
	define('TXT_S6','Par ailleurs, THOLDI est équipée d\'atelier de réparation pour conteneurs (Dry, Reefer, etc.) et propose des prestation d\'entretient et de réparation de conteneurs à ses clients et partenaires');
	define('TXT_S7','Elle offre les services suivants :');


	//Module de connexion
	define('TXT_CONNEXION','Se connectée');
	define('TXT_Username_HELP','Entrez votre nom d\'utillisateur ici.');
	define('TXT_MENU', 'Connexion');
	define('TXT_USERNAME','Nom d\'utillisateur : ');
	define('TXT_LOGIN', 'Mot de passe : ');
	define('TXT_Login_HELP', 'Entrez vorte mot de passe ici. Si vous ne vous en rappellez pas, utilisez le bouton mot de passe perdue.');
	define('TXT_NEW_ACC','Créer un compte.');
	define('TXT_RETRIVE_PSW','Mot de passe perdue ?');
	define('TXT_CONNEXION_SCREEN', 'Pour pouvoir accéder a l\'éspace clients, veuillez vous connectée.');
	define('TXT_VALID', 'Valider');
	define('TXT_RESET', 'Annuler');

	//Module de création de compte
	define('TXT_CREATE_MAIN', 'Pour pouvoir effectuer une reservation vous devez être connecté et avoir un compte chez nous.');
	define('TXT_CREATE_MAIN_2', 'Pour créer votre compte merci de remplir le formulaire ci-dessous.');
	define('TXT_LEGAL','Loi informatique du 6 janvier 1978');
	define('TXT_CREATE', 'Création de compte');
	

	define('TXT_NOM','Nom*');
	define('TXT_ADRS','Adresse*');
	define('TXT_CP','Code Postal*');
	define('TXT_CITTY','Ville*');
	define('TXT_PAYS', 'Pays*');
	define('TXT_MAIL','Adresse mail*');
	define('TXT_NOM_USER','Nom d\'utillisateur*');
	define('TXT_MDP','Mot de passe*');
	define('TXT_MDP_2','Ressaisir le mot de passe*');
	define('TXT_EXIST','Ce nom d\'utillisateur existe déjà');
	
	define('TXT_DECONNEXION','Se déconnecter');
	define('TXT_RESERVATION','Reservation');
	define('TXT_R0','Bienvenue sur votre espace !');
	define('TXT_R1','Vous pouvez effectuer :');
	define('TXT_R2','Vos réservation de conteneur');
	define('TXT_R3','Valider vos devis');
	define('TXT_R4','Consulter vos devis validés');
	define('TXT_R5','Consulter vos factures');
	define('TXT_RESERVER','Reserver');
	define('TXT_DEVIS','Devis');
	define('TXT_FACTURE','Factures');

	define('TXT_RE0', 'Réservation');
	define('TXT_RE1','Port Départ');
	define('TXT_RE2', 'Port d\'arrivée');
	define('TXT_RE3', 'Continent');
	define('TXT_RE4', 'Pays');
	define('TXT_RE5', 'Port');
	define('TXT_RE6', 'Date');
	define('TXT_RE7', 'Choisir le continent');
	define('TXT_Date_Help_IN','Choisisez ici la date du début de location');
	define('TXT_Date_Help_OUT','Choisisez ici la date de fin de location');

	define('TXT_CONT','Types de conteneurs');
	define('TXT_SIZE','Taille de conteneurs');
	define('TXT_NB','Nombre de conteneurs');
	define('TXT_PU','PU/Jour');
	define('TXT_TOTAL','Total');
	define('TXT_TTC','Total TTC');

	define('TXT_A','Arriver');
	define('TXT_D', 'Départ');
	define('TXT_SELECT_DATE','Selectionner votre date');
	define('TXT_SELECT_CONTENEUR','Selectionner vos conteneurs');
	define('TXT_ADD','Ajouter une ligne');
	define('TXT_EFF','Effacer');
	define('TXT_ACCEPTER', 'J\'accepte les MGV');
	
	define('TXT_DEVIS_INFO','Ce devis doit être validé pour être enregistré et pouvoir recevoir par mail sa version définitive. Il pourrat être modifié ultérieurement.<br>Il devra être validé dans les 3 mois.');
	define('TXT_DEVIS_INFO_2','Consulter nos modalités de ventes');

	define('TXT_FAIRERESA0','Pour faire votre réservation remplissez les imformations suivantes');
	define('TXT_FAIRERESA0_1','Pour modifier votre réservation modifier les imformations suivantes');
	define('TXT_FAIRERESA17', 'Choisir la taille');
	
	define('TXT_SERV', 'Services');

	define('TXT_RES_VAL','Votre réservaton a bien été pris en compte, si vous shouaitez consulter, modifier ou supprimer votre réservation rendez vous sur la page devis.');
	
	//---------------------------------------------------------
         // Devispdf.php
        //---------------------------------------------------------
        define('TXT_DEVISPDF1','DEVIS');
        define('TXT_DEVISPDF2','FACTURE');
        define('TXT_DEVISPDF3','Devis valable 3 mois');
        define('TXT_DEVISPDF4','Votre N° TVA INTRA');
        define('TXT_DEVISPDF4BIS','Notre N° TVA INTRA');
        define('TXT_DEVISPDF5','Vos conteneurs rÉservÉs');
        define('TXT_DEVISPDF6','QuantitÉ');
        define('TXT_DEVISPDF7','PU/jours');
        define('TXT_DEVISPDF8','TOTAL');
        define('TXT_DEVISPDF9','TOTAL HT');
        define('TXT_DEVISPDF10','TVA');
        define('TXT_DEVISPDF11','TOTAL TTC');
        define('TXT_DEVISINFO','Ce devis doit être validé pour être enregistré et pouvoir recevoir par mail sa version définitive. Il pourrat être modifié utérieurement.<br>Il devrat être validé dans les 3 mois.');
        define('TXT_DEVISINFO1','Consultez nos modalités de ventes');
        //---------------------------------------------------------
         // Devispdf.php
        //---------------------------------------------------------
        define('TXT_FINRESA1','Votre reservation est enregistrée.');
        define('TXT_FINRESA2','Elle est valable 3 mois ou 1 semaine avant la date de début. Passéz ce delais ce devis ext considéré comme nul.');
        define('TXT_FINRESA3','Vous devez le valider avant cette date.');
        define('TXT_FINRESA4','Vous allé rececevoir un mail avec votre devis.');
        define('TXT_MAIL1','Votre devis pour faire suite a votre demande de reservation'); 
        define('TXT_MAIL12','Bonjour');
        define('TXT_MAIL13','Vous venez de faire une demande de reservation. Vous trouverez ci-joint le devis correspondant à cette demande.<BR>Ce devis doit être validé dans les 3 mois ou 8 jours avant la date de debute de réservation si celle-ci est avant les 3 mois.');
        define('TXT_MAIL14','Vous venez de valider un devis.');
        define('TXT_MAIL15','Vous trouverez ci-joint la facture correspondant.');
        define('TXT_MAIL16','Cette facture est a régler sous 8 jours.');
        //---------------------------------------------------------
         // valider.inc.php
        //---------------------------------------------------------
        define('TXT_VALIDER0','Vous devez choisir le devis à valider ou à modifier');
        define('TXT_VALIDER1','Vos devis non validés');
        define('TXT_VALIDER2','N° de <br>devis');
        define('TXT_VALIDER3','Date de <br> réservation');
        define('TXT_VALIDER4','Modifier');
        define('TXT_VALIDER5','Supprimer');
        define('TXT_VALIDER6','Etat');
        //---------------------------------------------------------
         // MOdfiresa.php
        //---------------------------------------------------------
        define('TXT_MOFIRESA0','Vous ne pouvez valider cette réservation, elle est déjà validée.');
        define('TXT_MOFIRESA1','Vous ne pouvez supprimer cette réservation, elle est validée.');
        define('TXT_MOFIRESA2','Vous ne pouvez plus modifier cette réservation. Elle est validée ou annulée');
        define('TXT_MOFIRESA3','Votre réservation vient d\'être validée. Vous allez recevoir par mail une facture correspondant.');
        define('TXT_MOFIRESA4','Votre réservation vient d\'être Annulée.');
        define('TXT_MOFIRESA5','Votre réservation vient d\'être modifiée. Vous allez recevoir par mail une nouvelle vertion de votre devis.');
        define('TXT_MOFIRESA6','Vous venez de faire une modification de devis sur Tholdi.com.');
        define('TXT_MOFIRESA7','Vous trouverez ci-joint le devis correspondant à cette demande.');
        //---------------------------------------------------------
         // MDP.php
        //---------------------------------------------------------
        define('TXT_MDP0','Vous avez perdu votre login ou votre mot de passe');
        define('TXT_MPDP1','Saisir votre adresse mail utilisée pour vous enregistrer chez nous.');
        define('TXT_MPDP2','Il n\'y a pas de données avec cette adresse mail');
        define('TXT_MPDP3','Vous venez de faire une demande de vos login et mots de passe.Vous trouverez ci-desous ces informations.');
        define('TXT_MPDP4','Vos login et mots de passe THOLDI'); 
        define('TXT_MPDP5','Les information vous ont été envoyées par mail. Verifiez votre boîte aux lettre y compris les spam');
        //---------------------------------------------------------
         // factures.php
        //---------------------------------------------------------
        define('TXT_FAC0','Vous n\'avez aucunde facture actuellement');
        define('TXT_FAC1','Num Facture');
        define('TXT_FAC2','Vos Factures');
        //--------------
        // Erreur login
        //----------------
        define('TXT_DEJA','Il existe déjà un client avec ce login');
         define('TXT_DEJA1','Il existe déjà un client avec cette adresse mel');
        define('TXT_DEJA2','Si c\'est vous retounez sur la page login');
        define('TXT_DEJA3','Retour');
		
		define('TXT_VENTE','Vente');
		define('TXT_Tel','Téléphone')
?>
