<?php
// EN/GB - English

/*---------------------------------------------
 Menuhaut.inc.php
---------------------------------------------*/
	define('TXT_ACUEIL_INDEX', 'Home');
	define('TXT_CONTENEUR', 'Our Containers');
	define('TXT_SERVICE', 'Our Services');
	define('TXT_TARIFS', 'Our Prices');

	// Pied.inc.php
	define('TXT_MENTION', 'Legal Notice');
	define('TXT_AGENCE', 'Our Agencies : ');

	define('TXT_PRESENTATION', 'THOLDI is specialized in the management of containers for the transport of goods.');

	define('TXT_PRESENTATION2', 'It operates as a service provider for transport companies but has also been developing a freight activity since 2010 through its subsidiary "Eole".');
	
	define('TXT_PRESENTATION3', 'THOLDI head office is located in the Paris area and its activity areas are located in several European port facilities.');

	//Tarif.inc.php
	define('TXT_TITRETARIFS', 'Our prices');
	define('TXT_TARIFJOUR', 'Day');
	define('TXT_TARIFTRIM', 'Trimester');
	define('TXT_TARIFAN', 'Year');
	define('TXT_TITRE', 'Our containers');
	define('TXT_TYPE', 'Type of containers');
	define('TXT_IMAGE', 'Image');
	define('TXT_TAILLES', 'Size');

	//Conteneurs.inc.php
	define('TXT_DIM', 'They exist in differents sizes.');
	define('TXT_TOUS','All');

	//AccueilServices.inc.php
	define('TXT_S1','Its main activity is to: ');
	define('TXT_S2','Managing the unloading and reception of containers (checking their origin and the shipping company)');
	define('TXT_S3','Managing the placement in temporary storage areas');
	define('TXT_S4','Managing the loading of containers onto road or rail transport trailers');
	define('TXT_S5','Managing the "door-to-door" freight forwarding process');
	define('TXT_S6','In addition, THOLDI is equipped with a repair workshop for containers (Dry, Reefer, etc.) and offers container maintenance and repair services to its customers and partners');
	define('TXT_S7','It offers the following services :');

	//Module de connexion
	define('TXT_CONNEXION','Login in');
	define('TXT_Username_HELP','Enter your username her.');
	define('TXT_MENU','Login');
	define('TXT_USERNAME','Username');
	define('TXT_LOGIN', 'Password');
	define('TXT_Login_HELP','Enter your password here. If you can\'t remember it, use the lost password button');
	define('TXT_NEW_ACC', 'Create a new account.');
	define('TXT_RETRIVE_PSW', 'Lost your password ?');
	define('TXT_CONNEXION_SCREEN', 'To access the customer area, please log in.');
	define('TXT_VALID','Validate');
	define('TXT_RESET', 'Cancel');	

	//Module de création de compte
	define('TXT_CREATE_MAIN', 'To make a reservation you must be logged in and have an account with us.');
	define('TXT_CREATE_MAIN_2', 'To create your account please fill in the form below.');
	define('TXT_LEGAL','Computer law of 6 January 1978');
	define('TXT_CREATE','New Account');

	define('TXT_NOM','Name*');
	define('TXT_ADRS','Address*');
	define('TXT_CP','Postal code*');
	define('TXT_CITTY','Citty*');
	define('TXT_PAYS', 'Country*');
	define('TXT_MAIL','E-Mail*');
	define('TXT_NOM_USER','Username*');
	define('TXT_MDP','Password*');
	define('TXT_MDP_2','Re-enter the password*');
	define('TXT_EXIST','This Username already exist.');

	define('TXT_DECONNEXION','Disconnect');
	define('TXT_RESERVATION','Reservation');
	define('TXT_R0','Welcome to your space !');
	define('TXT_R1','You can perform :');
	define('TXT_R2','Your container reservation');
	define('TXT_R3','Validate your quotations');
	define('TXT_R4','View your validated quotations');
	define('TXT_R5','View your invoices');
	define('TXT_RESERVER','Book');
	define('TXT_DEVIS','Quotation');
	define('TXT_FACTURE','Invoices');
	
	define('TXT_RE0', 'Booking');
	define('TXT_RE1','Port Départ');
	define('TXT_RE2', 'Port d\'arrivée');
	define('TXT_RE3', 'Continent');
	define('TXT_RE4', 'Country');
	define('TXT_RE5', 'Port');
	define('TXT_RE6', 'Date');
	define('TXT_RE7', 'Select a continent');
	define('TXT_Date_Help_IN','Choose here the start date of the rental period');
	define('TXT_Date_Help_OUT','Choose here the end date of the rental period');

	define('TXT_CONT','Containers types');
	define('TXT_SIZE','Containers sizes');
	define('TXT_NB','Number of containers');
	define('TXT_PU','UP/Day');
	define('TXT_TOTAL','Total');
	define('TXT_TTC','Total TTC');

	define('TXT_A','Arrival');
	define('TXT_D', 'Departing');
	define('TXT_SELECT_DATE','Select your date');
	define('TXT_SELECT_CONTENEUR','Select your container');
	define('TXT_ADD','Add a line');
	define('TXT_EFF','Erase');
	define('TXT_ACCEPTER', 'I accept the MGV');
	
	define('TXT_DEVIS_INFO','This quote must be validated to be registered and to receive its final version by email. It can be modified at a later date.<br> It must be validated within 3 months.');
	define('TXT_DEVIS_INFO_2','Consult our terms and conditions of sale');

	define('TXT_FAIRERESA0','To make your reservation, please fill in the following information');
	define('TXT_FAIRERESA17', 'Select a size');
?>