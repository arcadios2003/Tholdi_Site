<!DOCTYPE html> <!-- Balise ouverture de HTML -->
<html>
	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Set up display to screen set up -->
		<link rel="stylesheet" type="text/css" href="CSS/Tholdi.css" media="all">
		<title>Tholdi</title>

	</head>
	<body>

		<div width="100%">
			<div id="site">
				
				<?php
					require_once 'include/Testlangue.inc.php';
					include 'include/entete.inc.php';
					if (!isset($_GET['val'])){
						include "include/aceuille.inc.php";
					} else {
						switch ($_GET['val']) {
							case 0:
								include 'include/aceuille.inc.php';
								break;
							case 3:
								include 'include/Tarif.inc.php';
								break;
							case 11:
								if(!isset($_GET['ag'])){
									include "include/Agences.inc.php";
								} else {
									include "include/Agence.inc.php";
								}
								break;
							case 1:
								include 'include/conteneurs/Conteneur.inc.php';
								break;
							case 2:
								include 'include/service/Services.inc.php';
								break;
							case 4:
								include 'include/connexion/Connection.inc.php';
								break;
							case 5:
								include 'include/connexion/Create.inc.php';
								break;
							case 7:
								include 'include/reservation/reservation.inc.php';
								break;
							case 8:
								include 'include/reservation/reserve.inc.php';
								break;
							case 9:
								include 'include/reservation/Devis.inc.php';
								break;
							case 10:
								include 'include/reservation/ModifDevis.inc.php';
								break;
							case 12:
								include 'include/reservation/Facture.inc.php';
								break;
							case 13 :
								include 'include/vente.inc.php';
								break;
							case 99:
								include 'include/Mention.inc.php';
								break;
							case 901;
								include 'include/connexion/already.inc.php';
								break;
							case 950;
								include 'include/connexion/deconnexion.php';
								break;
							case 999;
								include 'include/reservation/valid.inc.php';
								break;

						}
					}
				?>

			</div>
		</div>
		<?php include "Include/Pied.inc.php";?>
	</body>
</html>