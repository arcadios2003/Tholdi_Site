<?php
	// Call connexio creation code
	require_once('Connexion.inc.php');
	// Create var for SQL Request
	$str_requeteAG = "SELECT num, agencenom, paysnomgb, paysnomfr"
		. " FROM AGENCE JOIN PORT ON (agenceport=portcode) "
		. "JOIN PAYS on (portpays=payscode) ORDER BY AGENCE.num";
	//Execute Request
	$resultAG = $connexion->query($str_requeteAG);
?>

<div id="pied">
	<table id="tablepied">
		<tr>
			<td rowspan="4">&copy;Tholdi 2022</td>
			<td rowspan="4"><a href="index.php?val=99"><?php echo TXT_MENTION; ?></a></td>
			<td rowspan="4"> <a href="index.php?val=11"> <?php echo TXT_AGENCE; ?></a></td>

			<?php $i=0;
				while(($reponsesAG=$resultAG->fetch(PDO::FETCH_OBJ))){
					echo '<td> <a href="index.php?val=11&ag='.$reponsesAG->num.
					'">'.$reponsesAG->agencenom.' (';
					if ($lang=='fr'){
						echo $reponsesAG->paysnomfr;
					}else{
						echo $reponsesAG->paysnomgb;
					}
					echo ')</a> </td>';
					if ($i==1){
						echo '</tr>';
							$i=0;
					} else {
						$i=1;
					}
				}
			?>	
	</table>
</div>