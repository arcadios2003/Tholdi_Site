<?php 
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2);

if(isset($_COOKIE['lang'])){
	$lang = $_COOKIE['lang'];
}

if ($lang == 'fr'){
	include 'langue/fr.inc.php';
}
if ($lang == 'gb'){
	include 'langue/gb.inc.php';
}
setcookie("lang", $lang, time() + 3600, "/");
?>