<?php
	require_once("include/Connexion.inc.php");
	$str_reqtrans = "SELECT * FROM transport ORDER BY transcode";
	$result = $connexion->query($str_reqtrans);
?>

<br>
<table align="center" width="70%">
	<tr><td colspan="2"> <?php echo TXT_T1; ?></td></tr>
	<tr><td colspan="2"> <?php echo TXT_T2; ?></td> </tr>
	<tr><td><img src="Imgbase/transport/Transport_Toldi.jpg"></td></tr>
	<tr><td colspan="3" align="center">  <?php echo TXT_T3; ?></td> </tr>
<?php
while ($reponses = $result->fetch(PDO::FETCH_OBJ)){
	echo '<a>';
	if($lang == "fr"){
		echo '<tr><td colspan="2" align="center"><img src="Images/puce.jpg" width="25">';
		echo utf8_encode($reponses->transnom);
	} if ($lang == "gb") {
		echo '<tr><td colspan="2" align="center"><img src="Images/puce.jpg" width="25">';
		echo utf8_encode($reponses->transname);
	} if ($lang == "ru") {
		echo '<tr><td colspan="2" align="center"><img src="Images/puce.jpg" width="25">';
		echo utf8_encode($reponses->transname);
	}
	echo '</a>';
}
?>
</table>