<?php
	include "MenuTransports.inc.php";

	if(!isset($_GET['trans'])){
		include "AccueilTransports.inc.php";
	} else {
		if ($_GET['trans']==0){
			$str_requetec = "SELECT * FROM transport";
		} else{
		$str_requetec = "SELECT * FROM transport WHERE transcode =".$_GET['trans'];
	}
		$resultc = $connexion->query($str_requetec);
		while ($reponsesc = $resultc->fetch(PDO::FETCH_OBJ)){
		echo '<div align="center"><text id="titre0">';
		if ($lang=="fr"){
			echo utf8_encode($reponsesc->transnom);
		} if ($lang=="gb") {
			echo utf8_encode($reponsesc->transname);
		} if ($lang=="ru"){
			echo utf8_encode($reponsesc->transname);
		}
		echo '</text><br></div><table><tr><td>';
		if ($lang=="fr"){
			echo utf8_encode($reponsesc->transdescfr).'</td>';
		} if ($lang =="gb") {
			echo utf8_encode($reponsesc->transdescgb). '<td>';
		} if ($lang == "ru"){
			echo utf8_encode($reponsesc->transdescgb). '<td>';
		}
		echo '<td><img src="Imgbase/transport/'.$reponsesc->transimg.'"/>';
		echo '<tr><td colspan="2" align="left">';
		echo '<br>';
		echo '</td></tr></table>';
	}
}
?>