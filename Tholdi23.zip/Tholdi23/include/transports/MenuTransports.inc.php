<?php
	require_once('include/Connexion.inc.php');
	$str_reqserv = "SELECT * FROM transport ORDER BY transcode";
	$result = $connexion->query($str_reqserv);

	echo '<ul class="menu-vertical">';

	while ($reponses = $result->fetch(PDO::FETCH_OBJ)){
		echo '<li ';
		if (!isset($_GET['trans'])){
			echo 'class="mv-item">';
		} else
			if ($_GET['trans'] == $reponses->transcode){
				echo 'class="mv-itemactive">';
			} else {
				echo 'class="mv-item">';
			}
			echo '<a href="index.php?val=4&trans=';
			echo $reponses->transcode;
			echo '">';

			if ($lang == "fr"){
				echo utf8_encode($reponses->transnom);
			} if ($lang == "gb"){
				echo utf8_encode($reponses->transname);
			} if ($lang == "ru"){
				echo utf8_encode($reponses->transname);
			}
			echo '</a></li>';
		}
		echo '<li ';
		if (!isset($_GET['trans'])){
			echo 'class="mv-item">';
		} else {
			if($_GET['trans'] == 0) {
				echo 'class="mv-itemactive">';
			} else {
				echo 'class="mv-item">';
			}
		}
	echo '<a href="index.php?val=4&trans=0">'.TXT_TOUS.'</a></li>';

	echo '</ul>';
?>