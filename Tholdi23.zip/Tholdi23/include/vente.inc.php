<?php
	require_once('Connexion.inc.php');
	$str_rqtVente = "SELECT * FROM `contvente` JOIN contener ON (NumType=contcode) JOIN etatvente ON (IdEtat=NumEtat) JOIN port ON (NumPort=portcode) JOIN typecontener ON (conttype=typecode) JOIN taillecontener ON (conttaille=taillcode) ORDER BY IdCont ASC";
	$resVente = $connexion->query($str_rqtVente);
	
?>
</br>
</br>
<a href="index.php?val=4"><p style="text-align:center">Pour voir les prix, veuillez vous connecter</p></a>
<fieldset>
	<table align="center">
		<tr style="background-color:aliceblue">
			<td style="width:17%; text-align:center">N°Conteneur</td>
			<td style="width:17%; text-align:center">Type</td>
			<td style="width:17%; text-align:center">Taille</td>
			<td style="width:17%; text-align:center">Etat</td>
			<td style="width:17%; text-align:center">Port</td>
			<td style="width:17%; text-align:center">Prix</td>
		</tr>
		
	<?php
		while ($repVente = $resVente->fetch(PDO::FETCH_OBJ)){
			echo '<tr>';
			echo '<td align="center">'.$repVente->IdCont.'</td>';
			echo '<td align="center">'.$repVente->typelibel.'</td>';
			echo '<td align="center">'.$repVente->taillong.'"'.$repVente->taillarg.'"'.$repVente->taillhaut.'" </td>';
			echo utf8_encode('<td align="center">'.$repVente->LibelleEtat.'</td>');
			echo utf8_encode('<td align="center">'.$repVente->portnom.'</td>');
			if (isset($_COOKIE['id'])){
				echo '<td align="center">'.$repVente->Prix.' €</td>';
			} else {
				echo '<td align="center">'.'XXXXX €'.'</td>';
			}
			echo '</tr>';
		}
	?>
	</table>
</fieldset>

</br>
<a href="index.php?val=11"><p style="text-align:center"><?php echo TXT_Tel; ?></p></a>
