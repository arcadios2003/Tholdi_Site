<?php
	require_once('Connexion.inc.php');

	$str_reqAG = "SELECT * FROM AGENCE JOIN PORT ON (agenceport=portcode) JOIN PAYS ON (portpays=payscode) ORDER BY AGENCE.num";

	$resAG = $connexion->query($str_reqAG);

	$resultAG = $connexion->query($str_reqAG);

	while($repAG = $resAG->fetch(PDO::FETCH_OBJ)){
		
?>
<br>
<table width="100%">
	<tr>
		<td align="center"> <?php echo utf8_encode($repAG->agencenom); ?> </td>
	</tr>
	<tr>
		<td align="center"> <?php echo utf8_encode($repAG->agenceadrs1); ?> </td>
	</tr>
	<tr>
		<td align="center"> <?php echo utf8_encode($repAG->agenceadrs2); ?> </td>
	</tr>
	<tr>
		<td align="center"> <?php echo $repAG->agencecp." ".utf8_encode($repAG->agenceville); ?> </td>
	</tr>
	<tr>
		<td align="center"> <?php echo $repAG->agencetel; ?> </td>
	</tr>
	<tr>
		<td align="center"> <?php echo $repAG->agencemel; ?> </td>
	</tr>
	<tr>
		<td align="center"> <img src="<?php echo 'Imgbase/agences/'.$repAG->agenceimage; ?>" width="800"></td>
	</tr>
</table>

<?php } ?>