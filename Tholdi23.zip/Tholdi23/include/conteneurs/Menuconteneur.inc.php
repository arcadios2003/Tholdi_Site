<?php
require_once('include/Connexion.inc.php');
	$str_reqcont = "SELECT * FROM typecontener ORDER BY typecode";
	$result = $connexion->query($str_reqcont);

	echo '<ul class="menu-vertical">';

	while($reponses = $result->fetch(PDO::FETCH_OBJ)){
		echo '<li ';
		if(!isset($_GET['cont'])){					  // Si aucun Item n'a été séléctionnée
			echo 'class="mv-item">';
		} else 									  // Si un Item a été séléctionnée
			if($_GET['cont']==$reponses->typecode){ 	// Si cet Item est sélétionnée
				echo 'class="mv-itemactive">';
			} else {								  	// Pour tout les items non séléctionnée
				echo 'class="mv-item">';
			}
			echo '<a href="index.php?val=1&cont=';
			echo $reponses->typecode;
			echo '">';

			if ($lang == "fr"){
				echo $reponses->typelibel;
			} if ($lang == "gb") {
				echo $reponses->typelibelGB;
			} if ($lang == "ru"){
				echo $reponses->typelibelRU;
			}
			echo '</a></li>';
	}
	echo '<li ';
	if(!isset($_GET['cont'])){
		echo 'class="mv-item">';
	} else
	if($_GET['cont']==0 ){
		echo 'class="mv-itemactive">';
	} else {
		echo 'class="mv-item">';
	}
	echo '<a href="index.php?val=1&cont=0">'.TXT_TOUS.'</a></li>';

	echo '</ul>';
?>