<?php
	require_once("include/Connexion.inc.php");

	$str_reqCT = "SELECT * FROM CONTENER JOIN TYPECONTENER"
				." ON (typecontener=typecode) JOIN TAILLECONTENER"
				." ON (conttaille = taillcode ORDER BY CONTNER.conttype)";

	$resCT = $connexion->query($str_reqCT);
	$resultCT = $connexion->query($str_reqCT);

	while ($repCT = $resCT->fetch(PDO::FETCH_OBJ)) {
				$str_requetec = "SELECT * FROM typecontener WHERE typecode =".$_GET['cont'];
		$resultc = $connexion->query($str_requetec);
		$reponsesc = $resultc->fetch(PDO::FETCH_OBJ);
		echo '<div align="center"><text id="titre0">';
		if ($lang=="fr"){
			echo $reponsesc->typelibel;
		} if ($lang=="gb") {
			echo $reponsesc->typelibelGB;
		} if ($lang=="run"){
			echo $reponsesc->typelibelRU
		}
		echo '</text><br></div><table><tr><td>';
		if ($lang=="fr"){
			echo utf8_encode($reponsesc->descriptionfr).'</td>';
		} if ($lang=="gb") {
			echo utf8_encode($reponsesc->descriptiongb). '<td>';
		} if ($lang == "ru") {
			echo utf8_encode($reponsesc->descriptionru). '<td>';
		}
		echo '<td><img src="Imgbase/conteneur/'.$reponsesc->phototype.'"/>';

		echo '<tr><td colspan="2" align="left">';
		echo '<br>';
		echo TXT_DIM. '<br></td></tr>';
		echo '<tr><td colspan="2" align="center">';
		$str_requetaille = "SELECT * FROM CONTENER JOIN TAILLECONTENER"
						." ON(conttaille = taillcode) WHERE conttype=".$_GET['cont'];
		$resulttaille = $connexion->query($str_requetaille);
		while ($reponsestaille=$resulttaille->fetch(PDO::FETCH_OBJ)){
			echo $reponsestaille->taillong.'\'x'.
			$reponsestaille->taillarg.'\'x'.
			$reponsestaille->taillhaut.'<br>';
		}
		echo '</td></tr></table>';
	}
?>