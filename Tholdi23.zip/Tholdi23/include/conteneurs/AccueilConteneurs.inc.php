<?php
require_once("include/Connexion.inc.php");
$str_requete2 = "SELECT conttype, count(*) AS nb FROM CONTENER JOIN"
		." TAILLECONTENER ON (conttaille=taillcode) GROUP BY conttype"
		." ORDER BY conttype";
$result2 = $connexion->query($str_requete2);

$str_requete = "SELECT * FROM CONTENER JOIN TYPECONTENER ON"
		." (conttype=typecode) JOIN TAILLECONTENER ON (conttaille=taillcode)"
		." ORDER BY typecode, taillcode";
$result = $connexion->query($str_requete);
?>
<br>
<table align="center" width="80%" border="2">
	<th colspan="3"> <?php echo TXT_TITRE; ?></th>
	<tr>
		<td align="center"> <?php echo TXT_TYPE; ?> </td>
		<td align="center"> <?php echo TXT_IMAGE; ?> </td>
		<td align="center"> <?php echo TXT_TAILLES; ?> </td>
	</tr>

<?php
$typecode = -1;
while ($reponses = $result ->fetch(PDO::FETCH_OBJ)) {
	if ($typecode != $reponses -> typecode) {
		$reponses2 = $result2 -> fetch(PDO::FETCH_OBJ);
		echo '<tr><td align="center" rowspan="'.$reponses2->nb.'"/td>'
			.$reponses->typelibel.'</td><td align"center" rowspan="'
			.$reponses2->nb.'"><img src="imgbase/conteneur/'
			.$reponses->phototype.'"/></td>';
		$typecode=$reponses->typecode;
	}
	echo '<td align="center">'.$reponses->taillong.'\''
		.$reponses->taillarg.'\''. $reponses->taillhaut.'</td>';
	echo '</td></tr>';
}
?></table>