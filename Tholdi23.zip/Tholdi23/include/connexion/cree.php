<?php
require_once('../Connexion.inc.php');

$str_rqtVRF = 'SELECT COUNT(*) AS NB FROM client WHERE user ="'. $_POST['login'].'";';
$res_VRF = $connexion->query($str_rqtVRF);
$rep_VRF = $res_VRF->fetch(PDO::FETCH_OBJ);

if($rep_VRF->NB == 0){
	if($_POST['mdp'] == $_POST['mdp2']){
		$hash = password_hash($_POST['mdp'], PASSWORD_DEFAULT);

		$str_rqtINS = 'INSERT INTO client (user,hash,nom,adresse,CP,ville,pays,mail)VALUES("'.$_POST['login'].'","'.$hash.'","'.$_POST['nom'].'","'.$_POST['adresse'].'","'.$_POST['cp'].'","'.$_POST['ville'].'","'.$_POST['pays'].'","'.$_POST['mail'].'");';

		$resINS = $connexion->query($str_rqtINS);

		header('location:../../index.php?val=4');
	}
	else{
		echo $_SERVER['HTTP_REFERER'];
	}
}
else{
	header('location:../../index.php?val=901');
}

?>