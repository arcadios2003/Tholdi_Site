<br>
<p align="center"> <strong><?php echo TXT_CONNEXION_SCREEN ?></strong> </p>
<br>
<div align="center">
	<form action="include/connexion/conn.php" method="post">
		<fieldset id="entour">
			<legend> <?php echo TXT_MENU ?> </legend>
			<p align="center">
				<label for="Login" accesskey="l">*<?php echo TXT_USERNAME?></label>
				<input type="text" id="login" name="login" maxlength="30" size="18" value="" title="<?php echo TXT_Username_HELP?>">
			</p>
			<p align="center">
				<label for="Mdp" accesskey="m">*<?php echo TXT_LOGIN?></label>
				<input type="password" id="mdp" name="mdp" maxlength="32" size="18" value="" title="<?php echo TXT_Login_HELP ?>">
			</p>
			<p align="center">
				<input type="submit" id="ok" value="<?php echo TXT_VALID ?>">
				<input type="reset" id="annuler" value="<?php echo TXT_RESET?>">
			</p>
			<table width="90%">
				<tr>
					<td align="left">
						<a href="index.php?val=6"> <?php echo TXT_RETRIVE_PSW ?> </a>
					</td>
					<td align="right">
						<a href="index.php?val=5"> <?php echo TXT_NEW_ACC ?> </a>
					</td>
				</tr>
			</table>
		</fieldset>
	</form>
</div>