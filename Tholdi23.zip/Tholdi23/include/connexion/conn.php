<?php
require_once('../Connexion.inc.php');

$str_rqtCON = 'SELECT hash FROM client WHERE user="'.$_POST['login'].'";';
$res_CON = $connexion->query($str_rqtCON);
$rep_CON = $res_CON->fetch(PDO::FETCH_OBJ);


if(password_verify($_POST['mdp'], $rep_CON->hash) ){
	$str_rqtID = 'SELECT idcli FROM client WHERE user="'.$_POST['login'].'";';
	//echo $str_rqtID;
	$res_ID = $connexion->query($str_rqtID);
	$rep_ID = $res_ID->fetch(PDO::FETCH_OBJ);
	$r_ID=$rep_ID->idcli;

	
	ini_set('session.cookie_lifetime', 3600);
	setcookie('id', $r_ID, time()+86400,"/");
	header('location:../../index.php?val=7');
	
}
else{
	header('location:../../index.php?val=4');
	setcookie('user',"", time() - 3600,"/");
	setcookie('id',0, time() - 3600,"/");
	setcookie('encour',0,time() - 3600,"/");
}
?>