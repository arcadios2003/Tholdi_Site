<br><br>
	<fieldset>
	<table align="center">
		<tr>
			<td>
				<strong><?php echo TXT_EXIST ?></strong>
			</td>
		</tr>
		<tr>
			<td>
				<a href="index.php?val=4"><?php echo TXT_CONNEXION ?></a>
			</td>
			<td>
				<a href="index.php?val=5"><?php echo TXT_NEW_ACC?></a>
			</td>
		</tr>
	</table>
</fieldset>