<script type="text/javascript"> 
    function validate() { 
        var str = document.getElementById("mdp").value; 
            if (str.match( /[0-9]/g) && 
                    str.match( /[A-Z]/g) && 
                    str.match(/[a-z]/g) && 
                    str.match( /[^a-zA-Z\d]/g) &&
                    str.length >= 8) {
            	document.getElementById("mdp").style.backgroundColor = "#FFFFFF";
            }
  
            else 
                document.getElementById("mdp").style.backgroundColor = "#FF6B6B";  
        }

        function validate2(){
        	var str = document.getElementById("mdp").value;
        	var str2 = document.getElementById("mdp2").value;
        	if (str != str2){
        		document.getElementById("mdp2").style.backgroundColor = "#FF6B6B";
        	}
        	else {
        		document.getElementById("mdp2").style.backgroundColor = "#FFFFFF";
        		document.getElementById("tvb").value = 1;
        	}

        } 
</script> 

<?php 
	require_once("include/Connexion.inc.php");

	$str_rqtPAYS = "SELECT payscode,paysnomfr,paysnomgb FROM PAYS ORDER BY payscode";

	$resPAYS = $connexion->query($str_rqtPAYS);
	$liste="";
	while ($repPAYS = $resPAYS->fetch(PDO::FETCH_OBJ)){	
		if($lang == 'fr'){			
			$liste=$liste.'<option value="'.$repPAYS->payscode.'">'.utf8_encode($repPAYS->paysnomfr).'</option>';
		}
		else{
			$liste=$liste.'<option value="'.$repPAYS->payscode.'">'.utf8_encode($repPAYS->paysnomgb).'</option>';
		}
	}

 ?>

<br>
<p align="center"> <strong><?php echo TXT_CREATE_MAIN; ?></strong> </p>
<p align="center"> <strong><?php echo TXT_CREATE_MAIN_2; ?></strong></p>
<br>

<div align="center">
	<form action="./include/connexion/cree.php" method="post">
		<fieldset id="entour">
			<legend><?php echo TXT_CREATE; ?></legend>
			<table>
				<tr>
					<td width="45%" align="left"><label for="Nom" accesskey=""></label><?php echo TXT_NOM; ?></td>
					<td><input type="text" id="nom" name="nom" maxlength="30" size="20" value="" required=""></td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="Adresse" accesskey=""></label><?php echo TXT_ADRS; ?></td>
					<td><input type="text" id="adresse" name="adresse" maxlength="20" size="20" value="" required=""></td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="CP" accesskey=""></label><?php echo TXT_CP; ?></td>
					<td><input type="text" id="cp" name="cp" maxlength="6" size="8" value="" required=""></td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="Ville" accesskey=""><?php echo TXT_CITTY; ?></label></td>
					<td><input type="text" id="ville" name="ville" maxlength="15" size="20" value="" required=""></td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="Pays" accesskey=""><?php echo TXT_PAYS; ?></label></td>
					<td>
						<select id="pays" name="pays" required="">
							<option value="0"></option>
						<?php echo $liste; ?>
						
						</select>
					</td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="Mail" accesskey=""><?php echo TXT_MAIL; ?></label></td>
					<td><input type="text" id="mail" name="mail" maxlength="25" size="20" value="" required=""></td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="Login" accesskey=""><?php echo TXT_NOM_USER; ?></label></td>
					<td><input type="text" id="login" name="login" maxlength="30" size="20" value="" required=""></td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="Mdp" accesskey=""></label><?php echo TXT_MDP; ?></td>
					<td><input onfocusout="validate()" type="password" id="mdp" name="mdp" maxlength="24" size="20" value="" required=""></td>
				</tr>
				<tr>
					<td width="45%" align="left"><label for="ReMdp" accesskey=""><?php echo TXT_MDP_2; ?></label></td>
					<td><input onfocusout="validate2()" type="password" id="mdp2" name="mdp2" maxlength="24" size="20" value="" required=""></td>
				</tr>
			</table>
			<p align="center">
				<input type="text" id="tvb" hidden="" required="" value=""><input type="submit" id="ok" value="<?php echo TXT_VALID ?>">
				<input type="reset" id="annuler" value="<?php echo TXT_RESET?>">
			</p>
			<p align="center"><a href="https://www.legifrance.gouv.fr/loda/id/LEGITEXT000006068624/2019-06-04/"><?php echo TXT_LEGAL; ?></p></a>
		</fieldset>
	</form>
</div>
<br>
<br>
