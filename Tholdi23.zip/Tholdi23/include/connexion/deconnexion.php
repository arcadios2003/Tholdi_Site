<?php
setcookie('user',"", time() - 3600, "/");
setcookie('id',0, time() - 3600, "/");
setcookie('encour',0,time() - 3600, "/");
header('location: index.php?val=0');
?>