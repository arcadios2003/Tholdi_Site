<?php
	require_once('include/Connexion.inc.php');
	$str_reqserv = "SELECT * FROM service ORDER BY numservice";
	$result = $connexion->query($str_reqserv);

	echo '<ul class="menu-vertical">';

	while ($reponses = $result->fetch(PDO::FETCH_OBJ)){
		echo '<li ';
		if (!isset($_GET['serv'])){
			echo 'class="mv-item">';
		} else
			if ($_GET['serv'] == $reponses->numservice){
				echo 'class="mv-itemactive">';
			} else {
				echo 'class="mv-item">';
			}
			echo '<a href="index.php?val=2&serv=';
			echo $reponses->numservice;
			echo '">';

			if ($lang == "fr"){
				echo utf8_encode($reponses->nomserviceFR);
			} if ($lang == "gb"){
				echo utf8_encode($reponses->nomserviceGB);
			} if ($lang == "ru"){
				echo utf8_encode($reponses->nomserviceRU);
			}
			echo '</a></li>';
		}
		echo '<li ';
		if (!isset($_GET['serv'])){
			echo 'class="mv-item">';
		} else {
			if($_GET['serv'] == 0) {
				echo 'class="mv-itemactive">';
			} else {
				echo 'class="mv-item">';
			}
		}
	echo '<a href="index.php?val=2&serv=0">'.TXT_TOUS.'</a></li>';

	echo '</ul>';
?>