<?php
	include "Menuservices.inc.php";

	if(!isset($_GET['serv'])){
		include "AccueilServices.inc.php";
	} else {
		if ($_GET['serv']==0){
			$str_requetec = "SELECT * FROM service";
		} else{
		$str_requetec = "SELECT * FROM service WHERE numservice =".$_GET['serv'];
	}
		$resultc = $connexion->query($str_requetec);
		while ($reponsesc = $resultc->fetch(PDO::FETCH_OBJ)){
		echo '<div align="center"><text id="titre0">';
		if ($lang=="fr"){
			echo utf8_encode($reponsesc->nomserviceFR);
		} if ($lang=="gb") {
			echo utf8_encode($reponsesc->nomserviceGB);
		} if ($lang=="ru"){
			echo utf8_encode($reponsesc->nomserviceRU);
		}
		echo '</text><br></div><table><tr><td>';
		if ($lang=="fr"){
			echo utf8_encode($reponsesc->descriptionFR).'</td>';
		} if ($lang =="gb") {
			echo utf8_encode($reponsesc->descriptionGB). '<td>';
		} if ($lang == "ru"){
			echo utf8_encode($reponsesc->descriptionRU). '<td>';
		}
		echo '<td><img src="Imgbase/service/'.$reponsesc->servimage.'"/>';
		echo '<tr><td colspan="2" align="left">';
		echo '<br>';
		echo '</td></tr></table>';
	}
}
?>