<?php
	require_once("include/Connexion.inc.php");
	$str_reqserv = "SELECT * FROM service ORDER BY numservice";
	$result = $connexion->query($str_reqserv);
?>
<br>
<table align="center" width="80%">
	<tr><td colspan="2"> <?php echo TXT_S1; ?></td></tr>
	<tr><td width="32" align="right"><img src="Images/puce.jpg" width="30"></td><td> <?php echo TXT_S2; ?></td> </tr>
	<tr><td width="32" align="right"><img src="Images/puce.jpg" width="30"></td><td> <?php echo TXT_S3; ?> </td></tr>
	<tr><td width="32" align="right"><img src="Images/puce.jpg" width="30"></td><td> <?php echo TXT_S4; ?> </td></tr>
	<tr><td width="32" align="right"><img src="Images/puce.jpg" width="30"></td><td> <?php echo TXT_S5; ?> </td></tr>
	<tr><td colspan="2">  <?php echo TXT_S6; ?></td> </tr>
	<tr><td colspan="3" align="center">  <?php echo TXT_S7; ?></td> </tr>
<?php
while ($reponses = $result->fetch(PDO::FETCH_OBJ)){
	echo '<a>';
	if($lang == "fr"){
		echo '<tr><td colspan="2" align="center"><img src="Images/puce.jpg" width="25">';
		echo utf8_encode($reponses->nomserviceFR);
	} if ($lang == "gb") {
		echo '<tr><td colspan="2" align="center"><img src="Images/puce.jpg" width="25">';
		echo utf8_encode($reponses->nomserviceGB);
	} if ($lang == "ru") {
		echo '<tr><td colspan="2" align="center"><img src="Images/puce.jpg" width="25">';
		echo utf8_encode($reponses->nomserviceRU);
	}
	echo '</a>';
}
?>

</table>