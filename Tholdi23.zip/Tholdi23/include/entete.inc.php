<table id="entete">
	<!-- Mise en place d'un tableau pour l'entète -->
	<tr>
		<td>
			<img src="Images/Tholdisimple.png" id ="logo"> <!-- Insérer le logo -->
		</td>
		<td>
			<text id = "titre0"> Storage And Shipping </text>
		</td>
		<td>
			<select class="language_selector"
				onchange="document.cookie= 'lang=' +
					this.value; window.location.reload();">
				<option value="fr" <?php if ($lang=="fr")
					{echo 'selected="SELECTED"';} ?> > Français</option>
				<option value="gb" <?php if ($lang=="gb")
					{echo 'selected="SELECTED"';} ?> > English (UK)</option>
			</select>
		</td>
	</tr>

	<tr>
		<td colspan="3">
			<?php include "Menuhaut.inc.php"; ?>
		</td>
	</tr>

</table>