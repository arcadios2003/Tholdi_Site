<?php
include('MenuReservation.inc.php');
require_once('include/Connexion.inc.php');

if(!isset($_COOKIE['id'])) {
	header('location:index.php?val=4');
}

$str_rqtRES = 'SELECT nom FROM client WHERE idcli ="'.$_COOKIE['id'].'";';
$res_RES = $connexion->query($str_rqtRES);
$rep_RES = $res_RES->fetch(PDO::FETCH_OBJ);
?>

<strong><?php echo $rep_RES->nom;?></strong>
<p><?php echo TXT_R0?></p>
<p><?php echo TXT_R1?></p>
<table align="center">
	<tr>
		<td width="32" align="right"><img src="Images/puce.jpg" width="30"></td>
		<td> <?php echo TXT_R2; ?></td>
	</tr>
		<tr>
		<td width="32" align="right"><img src="Images/puce.jpg" width="30"></td>
		<td> <?php echo TXT_R3; ?></td>
	</tr>
		<tr>
		<td width="32" align="right"><img src="Images/puce.jpg" width="30"></td>
		<td> <?php echo TXT_R4; ?></td>
	</tr>
		<tr>
		<td width="32" align="right"><img src="Images/puce.jpg" width="30"></td>
		<td> <?php echo TXT_R5; ?></td>
	</tr>
</table>