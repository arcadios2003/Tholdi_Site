<link rel="stylesheet" type="text/css" href="CSS/Calendrier.css" media="all"/>
<?php 
$v=1;
require_once('Include/Connexion.inc.php');

include('java/dept_xhr.js');
include('java/Calendrier.js');
include('java/Fonctionformulaire.php');
if(!isset($_SESSION['encour'])){
    header('location:index.php?val=5');
}else{
    $sql_client="SELECT * FROM client JOIN pays ON (pays=payscode) WHERE idcli =1";
    $resclient = $connexion->query($sql_client);
    $repclient = $resclient->fetch(PDO::FETCH_OBJ);


    if ($lang == 'fr'){
        $str_reqcontinent = "SELECT contnum, connomfr as nom FROM  continent order by connomfr";
       $lng=1;
        
    }else{
        $str_reqcontinent = "SELECT contnum, connomgb as nom FROM  continent order by connomgb";
        $lng=2;
        
    }
    $rescontinent = $connexion->query($str_reqcontinent);
    $listecontinent="<option value='-1'>".TXT_FAIRERESA5."</option>"; 

    while(($repcontinent = $rescontinent->fetch(PDO::FETCH_OBJ))){
     $listecontinent=$listecontinent.'<option value="'.$repcontinent->contnum.'">'.$repcontinent->nom.'</option>';
    }

    // liste des type conteneurs
    $str_reqtype="SELECT typecode, typelibel from  typecontener";
    $restypeconteneurs = $connexion->query($str_reqtype);
    
    $typeconteneurs="<option value='-1'>".TXT_FAIRERESA16."</option>"; 
     while(($reptypeconteneur = $restypeconteneurs->fetch(PDO::FETCH_OBJ))){
     $typeconteneurs=$typeconteneurs.'<option value="'.$reptypeconteneur->typecode.'">'.$reptypeconteneur->typelibel.'</option>';
    }  
    ?>



    <div align="center">
        <br><?php echo TXT_FAIRERESA0; ?>
    </div>
        <br>

        <fieldset>
            <legend> <?php echo TXT_FAIRERESA00; ?></legend>
        <form  action="Include/Resa/Valideresa.php?modif=1"  method="post" onsubmit="return verifForm2(this);">
        <input name="lang" hidden value="<?php echo $lang; ?>"><br>

        <fieldset id="field1"> 
                <legend> <?php echo TXT_FAIRERESA1." ".TXT_FAIRERESA1BIS; ?></legend>
                <label for="continentD"><?php echo TXT_FAIRERESA2; ?></label>
                <select required name="continentD"  id="continentD"
                   <?php if ($lang == 'fr'){
                     echo 'onchange="getPays(this.value,1,1);" title="'.TXT_FAIRERESA5.'"'; 
                   }else{
                     echo 'onchange="getPays(this.value,1,2);" title="'.TXT_FAIRERESA5.'"';
                   }
                   ?>
                        >
                   <?php echo $listecontinent; ?>
       </select><br><br>
                <label for="paysD"><?php echo TXT_FAIRERESA3; ?></label>
                <span id="blocPaysD"></span><br><br>
                <label for="port1"><?php echo TXT_FAIRERESA4; ?></label>
                <span id="blocPortD"></span><br><br>
                 <label for="dateD"><?php echo TXT_FAIRERESA8; ?></label>
                 <input required  type="text" name="dateD" id="dateD" class="calendrier" onsize="8" title="<?php echo TXT_FAIRERESA9; ?>" />
        </fieldset>

        <fieldset> 
                <legend> <?php echo TXT_FAIRERESA1." ".TXT_FAIRERESA1TER; ?></legend>
                <label for="continentA"><?php echo TXT_FAIRERESA2; ?></label>
                <select required name='continentA' id='continentA' 
                   <?php if ($lang == 'fr'){
                     echo 'onchange="getPays(this.value,2,1);" title="'.TXT_FAIRERESA5.'"'; 
                   }else{
                     echo 'onchange="getPays(this.value,2,2);" title="'.TXT_FAIRERESA5.'"';
                   }
                   ?>
                        >
                    <?php echo $listecontinent; ?>
                    </select><br><br>
                     <label for="paysA"><?php echo TXT_FAIRERESA3; ?></label>
                    <span id="blocPaysA"></span><br><br>
                    <label for="port2"><?php echo TXT_FAIRERESA4; ?></label>
                    <span id="blocPortA"></span><br><br>
                 <label for="dateA"><?php echo TXT_FAIRERESA8; ?></label>
                 <input required  type="text" name="dateA" id="dateA" class="calendrier"  size="8" title="<?php echo TXT_FAIRERESA9; ?>" />
        </fieldset>
         <fieldset>
             <legend> <?php $nb=1;echo TXT_FAIRERESA10;  ?> </legend>
             <table border="1" width="98%" id="tableresa">
                 <tr><td width="20%" align="center"><?php echo TXT_FAIRERESA11; ?></td>
                     <td width="20%" align="center"><?php echo TXT_FAIRERESA12; ?></td>
                     <td width="20%" align="center"><?php echo TXT_FAIRERESA13; ?></td>
                     <td width="20%" align="center"><?php echo TXT_DEVISPDF7; ?></td>
                     <td align="center"><?php echo TXT_DEVISPDF8; ?></td>
                 </tr>
                 <tr><td><select required name="typeconteneur-<?php echo $nb;?>"  id="typeconteneur-<?php echo $nb;?>" onchange="gettaille(this.value,<?php echo $nb;?>,<?php echo $lng;?>);" required><?php echo $typeconteneurs; ?> </select></td>
                     <td><span id="taille<?php echo $nb;?>"></span></td>
                     <td><input min=0 type="number" name="qte-<?php echo $nb;?>" id="qte-<?php echo $nb;?>" onblur="getprix(<?php echo $nb;?>,<?php echo $lng;?>,'<?php echo $repclient->clipays ;?>',<?php echo $repclient->UE ;?>);"></td>
                     <td align="right"><span id="prix<?php echo $nb;?>"></span></td>
                     <td align="right"><span hidden id="total<?php echo $nb;?>"></span><span id="tot<?php echo $nb;?>"></span></td>
                 </tr>


                 <tr><td style="border-left-style: none;border-bottom-style: none;" colspan="2" ></td>
                     <td colspan="2" align="center" >TOTAL</td>
                     <td align="right"><span id="totalgeneral"></span></td>
                 </tr>

                 <tr><td style="border-top: none; border-left-style: none;border-bottom-style: none;"colspan="2" ></td>
                     <td align="center" >TVA</td>
                     <td align="center" ><span id="tauxtva">20%</span></td>
                     <td align="right"><span id="tva"></span></td>
                 </tr>
                 <tr><td style="border-top: none; border-left-style: none;border-bottom-style: none;"colspan="2" ></td>
                     <td colspan="2" align="center">TOTAL TTC</td>
                     <td align="right"><span id="totalttc"></span></td>
                 </tr>
            </table>
             <!--<input type="button" onclick="ajouterligne(<?php echo $lng; ?>,<?php echo "'".$repclient->clipays."'" ;?>,<?php echo $repclient->UE ;?>,1)" value="<?php echo TXT_FAIRERESA14; $nb++;?>" />-->
      </fieldset>

            <table width="100%">
                <tr><td align="center"><input type="reset" id="annuler" value="<?php echo TXT_EF; ?>" /></td>
                    <td><input type="submit" id="ok" value="<?php echo TXT_BTV; ?>" /></td>
                    
                    <td align="center"><input type="button" id="annuler" value="<?php echo TXT_AN; ?>" onclick="javascript:history.go(-1);" /></td>
                </tr>
            </table>
        <input type="checkbox" required> <?php echo TXT_ACCEPTER; ?>
        </form> 
          <?php echo TXT_DEVISINFO;
          echo "<br>".TXT_DEVISINFO1;?>  
    </fieldset>
<?php } ?>