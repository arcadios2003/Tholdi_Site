<?php

require_once('../Connexion.inc.php');

if(!isset($_COOKIE['id'])) {
	header('location:../index.php?val=4');
}
$lang = $_COOKIE['lang'];
$deb=0;
if($_GET['modif']==1){
	while (list($indice,$value)=each($_POST)){
		if($deb==0){
			switch($indice) {
				case 'port1' : $portdepart=$value;
					break;
				case 'port2' : $portarrivee=$value;
					break;
				case 'dateD' : $datedepart = new DateTime(implode('-', array_reverse(explode('/', $value))));
					break;
				case 'dateA' : $datearrivee = new DateTime(implode('-', array_reverse(explode('/', $value))));
					break;
				case 'id' : $id = $value;
					$interval = $datedepart->diff($datearrivee, true);
					$duree = $interval->format('%a')+1;
					$cli= $_COOKIE['id'];
					$req_aj="UPDATE devis SET devetat = 1,portA = '".$portarrivee."',portD = '".$portdepart."',dateDpt = '".$datedepart->format('y-m-d')."',dateArv = '".$datearrivee->format('y-m-d')."',devdat = '".date('Y-m-d')."',duree = ".$duree." WHERE devinum =".$id;
					$res_aj=$connexion->query($req_aj);
					$deb = 1;
					$recup ="SELECT max(devinum) as num FROM devis WHERE devcli=".$_COOKIE['id'];
					$recup_nump=$connexion->query($recup);
					$reprecup = $recup_nump->fetch(PDO::FETCH_OBJ);
					$numresa = $reprecup->num;
					break;
			}
		} else {
			list($val1, $val2) = explode('-',$indice);
			switch($val1){
				case 'typeconteneur':$conteneurs=$value;
					break;
				case 'taille' : $taille=$value;
					break;
				case 'qte' : $qte=$value;
					break;
				case 'id' : $id = $value;
					if($val2==1){
						$req_ajcont="UPDATE detaildevis SET devinum = ".$numresa.",contcode = ".$conteneurs.$taille.",qtecont = ".$qte." WHERE devinum=".$id;
					} else {
						$verif = "SELECT count(*) as nb from detaildevis WHERE devinum = ".$numresa." and contcode=".$conteneurs.$taille;
						$recup_verif = $connexion->query($verif);
						$rep_verif = $recup_verif->fetch(PDO::FETCH_OBJ);
						if($rep_verif->nb == 0 && $qte != 0) {
							$requ_ajcont="UPDATE detaildevis SET devinum = ".$numresa.",contcode = ".$conteneurs.$taille.",qtecont = ".$qte." WHERE devinum=".$id;
						} else {
							if($rep_verif->nb !=0) {
								if($qte != 0) {
									$req_ajcont="UPDATE detaildevis SET qte = qte +".$qte." WHERE devinum=".$numresa." AND contcode=".$conteneurs.$taille;
								} else {
									$req_ajcont="DELETE FROM detaildevis WHERE devinum =".$numresa." AND contcode =".$conteneurs.$taille;
								}
							}
						}
					}
					$res_ajoutcont = $connexion->query($req_ajcont);
					break;
				case 'totg' : $totg = $value;
					break;
				case 'tva' : $tva = $value;
					$maj = "UPDATE devis SET TTC = ".$totg." WHERE devinum =".$numresa;
					$recup_maj = $connexion->query($maj);
			}
		}
	}
	$type = 1;
} else {
	while (list($indice,$value)=each($_POST)){
		if($deb==0){
			switch($indice){
				case 'resa' : $numresa = $value;
					break;
				case 'port1' : $portdepart = $value;
					break;
				case 'port2' : $portarrivee = $value;
					break;
				case 'dateD' : $datedepart = new DateTime(implode('-',array_reverse(explode('/','$value'))));
					break;
				case 'dateA' : $datearrivee = new DateTime(implode('-',array_reverse(explode('/','$value'))));
					$interval = $datedepart->diff($datearrivee,true);
					$duree = $interval->format('%a') + 1;
					$cli = $_COOKIE['id'];
					$req_aj = "UPDATE devis SET devdat='".date('Y-m-d')."', dateDpt='".$datedepart->format('y-m-d')."', dateArv ='".$datearrivee->format('y-m-d')."', portD='".$portdepart."', portA='".$portarrivee."', duree=".$duree." WHERE devinum=".$numresa;
					$res_aj = $connexion->query($req_aj);
					$deb=1;
					break;
			}
		} else {
			list($val1, $val2) = explode("-",$indice);
			switch($val1){
				case 'typeconteneur' : $conteneurs=$value;
					break;
				case 'taille' : $taille=$value;
					break;
				case 'qte' : $qte=$value;
					break;
				case 'id' : $id = $value;
					$verif = "SELECT count(*) as nb from detaildevis WHERE devinum=".$numresa." and contcode=".$conteneurs.$taille;
					$recup_verif = $connection->query($verif);
					$rep_verif=$recup_verif->fetch(PDO::FETCH_OBJ);
					if($rep_verif->nb == 0 && $qte != 0) {
						$req_ajcont="UPDATE detaildevis SET devinum = ".$numresa.", contcode = ".$conteneurs.$taille.", qtecont = ".$qte."WHERE devinum=".$id;
					} else {
						if($rep_verif->nb != 0) {
							if($qte != 0) {
								$req_ajcont="UPDATE detaildevis SET qtecont=".$qte."where devinum=".$numresa." AND contcode=".$conteneurs.$taille;
							} else {
								$req_ajcont="DELETE FROM detaildevis WHERE devinum=".$numresa."AND contcode=".$conteneurs.$taille;
							}
						}
					}
					$res_ajoutcont= $connexion->query($req_ajcont);
					break;
				case 'totg' : $totg = $value;
					break;
				case 'tva' : $tva=$value;
					$maj = "UPDATE devis SET TTC=".$totg." WHERE devinum=".$numresa;
			}
		}
	}
	$type=1;
	unlink("../../Devis/Devis_".$numresa.".pdf");
}

include 'devispdf.inc.php';
//header('location: ../../index.php?val=999');
?>