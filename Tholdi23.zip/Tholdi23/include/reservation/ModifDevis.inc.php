<?php
require_once('include/Connexion.inc.php');

list($devinum,$devetat) = explode("-",$_POST['resa']);
$fait = 0;
switch ($_POST['Val']){
	
	case 0 :
		if($devetat==1){
			$sql_numfac = "SELECT MAX(numfact) AS num FROM devis";
			$result_numfac = $connexion->query($sql_numfac);
			$rep_numfac = $result_numfac->fetch(PDO::FETCH_OBJ);
			$numfac=$rep_numfac->num+1;
			$req="UPDATE devis SET devetat=2, numfact=".$numfac." WHERE devinum=".$devinum;
			$resetat = $connexion->query($req);
			$type = 2;
			$numresa=$devinum;
			require 'include/reservation/Devispdf.inc.php';
			
			$message=TXT_MOFIRESA3;
		} else {
			$message=TXT_MOFIRESA0;
		}
		break;
	case 1 :
		if($devetat==1){
			include('Modifieresa.inc.php');
			$fait = 1;
		} else {
			$message = TXT_MOFIRESA2;
		}
		break;
	case 2 :
		if($devetat==1){
			$req="UPDATE devis SET devetat=3 WHERE devinum=".$devinum;
			$resetat = $connexion->query($req);
			$message = TXT_MOFIRESA4;
		} else {
			$message = TXT_MOFIRESA1;
		}
		break;
}?>
<div align="center">
<?php if ($fait==0) {
	include('MenuReservation.inc.php');
	echo $message;
} ?>
</div>