<?php
require_once('../Connexion.inc.php');
$idr = isset($_GET['idr']) ? $_GET['idr'] : false;
$nb = $_GET['nb'];
$lng = $_GET['lng'];
if($lng==1){
	include "../../langue/fr.inc.php";
} else {
	include "../../langue/gb.inc.php";
}
if(false !== $idr) {
	$sql2 = "SELECT taillcode, taillong, taillarg, taillhaut".
			" FROM taillecontener JOIN contener ON (taillcode = conttaille)".
			" WHERE conttype = ". $idr;
	$restaille = $connexion->query($sql2);
	$nd = 0;
	$code_taille = array();
	$nom_taille = array();

	while (false != ($reptaille = $restaille->fetch(PDO::FETCH_OBJ))){
		$code_taille[] = $reptaille->taillcode;
		$nom_taille[] = $reptaille->taillong."'x".$reptaille->taillarg."' x".$reptaille->taillhaut;
		$nd++;  
	}
	$liste = "";
	$liste .= "<select required name='taille-".$nb."' id='taille-".$nb."'>";
	$liste .= "option value='-1'>".TXT_FAIRERESA17."</option>";

	for($d = 0; $d < $nd; $d++){
		$liste .= '<option value="'.$code_taille[$d].'">'. htmlentities($nom_taille[$d]).'</option>'."";
	} 
	$liste .= '</select>'."\n";
	echo($liste);
} else {
	if($lng = 'fr'){
		echo("<p> Une erreur s'est produite. La région sélectionnée comporte une donnée invalide.</p>\n");
	} else {
		echo ("<p>An error has occurred. The selected region has an invalid data. </p> \n");
	}
}
?>