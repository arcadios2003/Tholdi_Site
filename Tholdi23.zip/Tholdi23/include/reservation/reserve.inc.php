<link rel="stylesheet" type="text/css" href="CSS/Calendrier.css" media="all">
<?php
if(!isset($_COOKIE['id'])) {
	header('location:../index.php?val=4');
} else {
require_once('include/Connexion.inc.php');

include('Java/dept_xhr.js');
include('Java/Calendrier.js');
include('Java/Fonctionformulaire.php');
	$sql_client = "SELECT * FROM client JOIN pays ON (pays=payscode) WHERE idcli =1";//
	
	$resclient = $connexion->query($sql_client);
	$repclient = $resclient->fetch(PDO::FETCH_OBJ);

	if($lang == 'fr') {
		$str_rqtcontinent = "SELECT contnum, connomfr as nom FROM continent ORDER BY connomfr";
		$lng=1;
	} else {
		$str_rqtcontinent = "SELECT contnum, connomgb as nom FROM continent ORDER BY connomgb";
		$lng=2;
	}

	$rescontinent = $connexion->query($str_rqtcontinent);
	$listecontinent = "<option value='-1'>". TXT_RE7."</option>";

	while ($repcontinent = $rescontinent->fetch(PDO::FETCH_OBJ)) {
		$listecontinent=$listecontinent.'<option value="'.$repcontinent->contnum.'">'.$repcontinent->nom.'</option>';
	}

	$str_reqtype="SELECT typecode, typelibel FROM typecontener";
	$restypeconteneurs = $connexion->query($str_reqtype);
	$typeconteneurs = "<option value='-1'>".TXT_CONT."</option>";
	while ($reptypeconteneur = $restypeconteneurs->fetch(PDO::FETCH_OBJ)) {
		$typeconteneurs=$typeconteneurs.'<option value="'.$reptypeconteneur->typecode.'">'.$reptypeconteneur->typelibel.'</option>';		
	}
}
?>

<div align="center">
	<br><?php echo TXT_FAIRERESA0; ?>
</div>
	<br>
	<fieldset>
		<legend> <?php echo TXT_RESERVATION; ?></legend>
		<form action="include/reservation/valideresa.php?modif=1" method="post" onsubmit="return verifForm2(this);">
			<input name="lang" hidden value="<?php echo $lang ?>"><br>
			<fieldset id="field1">
				<legend> <?php echo TXT_RE5." ".TXT_D; ?></legend>
				<label for="continentD"><?php echo TXT_RE3; ?></label>
				<select required name="continentD" id="continentD" 
					<?php if($lang=='fr'){
						echo 'onchange="getPays(this.value,1,1);" title="'.TXT_RE7.'"';
					} else {
						echo 'onchange="getPays(this.value,1,2);" title="'.TXT_RE7.'"';
					}
					 ?>
					 	>
				<?php echo utf8_encode($listecontinent); ?>
				</select> <br> <br>
					<label for="paysD"><?php echo TXT_RE4; ?></label>
					<span id="blocPaysD"></span><br><br>
					<label for="port1"><?php echo TXT_RE5; ?></label>
					<span id="blocPortD"></span><br><br>
					<label for="dateD"><?php echo TXT_RE6; ?></label>
					<input required type="text" name="dateD" id="dateD" class="calendrier" onsize="8" title="<?php echo TXT_SELECT_DATE; ?>">
			</fieldset>

			<fieldset>
				<legend><?php echo TXT_RE5." ".TXT_A; ?></legend>
				<label for="contientA"><?php echo TXT_RE3; ?></label>
				<select required name="contientA" id="contientA" <?php if($lang=='fr') {echo 'onchange="getPays(this.value,2,1);" title="'.TXT_RE7.'"';} else { echo 'onchange="getPays(this.value,2,2)" title="'.TXT_RE7.'"';} ?>>
				<?php echo utf8_encode($listecontinent) ?>
				</select> <br> <br>
					<label for="paysA"><?php echo TXT_RE4; ?></label>
					<span id="blocPaysA"></span><br><br>
					<label for="port2"><?php echo TXT_RE5; ?></label>
					<span id="blocPortA"></span><br><br>
					<label for="dateA"><?php echo TXT_RE6; ?></label>
					<input required type="text" name="dateA" id="dateA" class="calendrier" onsize="8" title="<?php echo TXT_SELECT_DATE; ?>">
			</fieldset>
			<fieldset>
				<legend><?php $nb=1; echo TXT_SELECT_CONTENEUR; ?></legend>
				<table border="1" width="98%" id="tableresa">
					<tr>
						<td width="20%" align="center"><?php echo TXT_CONT; ?></td>
						<td width="20%" align="center"><?php echo TXT_SIZE; ?></td>
						<td width="20%" align="center"><?php echo TXT_NB; ?></td>
						<td width="20%" align="center"><?php echo TXT_PU; ?></td>
						<td align="center"><?php TXT_TOTAL; ?></td>
					</tr>
					<tr>
						<td>
							<!--Sélection du Type de Contener-->
							<select required name="typeconteneur-<?php echo $nb;?>" id="typeconteneur-<?php echo $nb; ?>" onchange="gettaille(this.value,<?php echo $nb; ?>, <?php echo $lng;?>);" required><?php echo $typeconteneurs ?></select>
						</td>
						<td>
							<!--Sélection de la taille de contener-->
							<span id="taille-<?php echo $nb; ?>"></span>
						</td>
						<td>
							<!--Sélection du nombre de contener-->
							<input min="0" type="number" name="qte-<?php echo $nb; ?>" id="qte-<?php echo $nb; ?>" onblur="getprix(<?php echo $nb;?>, <?php echo $lng; ?>)"/>
						</td>
						<td align="right">
							<!--Prix Unitaire du Contener-->
							<span  id="prix<?php echo $nb; ?>"></span>
						</td>
						<td align="right">
							<!--Total de ce contener sans TVA-->
							<span  id="total<?php echo $nb;?>"></span>
						</td>
					</tr>
					<tr>
						<td style="border-left-style: none; border-bottom-style: none;" colspan="2"></td>
						<td colspan="2" align="center">Total</td>
						<td align="right"><span id="totalgeneral"></span></td>
					</tr>
					<tr>
						<td style="border-top: none; border-left-style: none; border-bottom-style: none;" colspan="2"></td>
						<td align="center">TVA</td>
						<td align="center"><span id="tauxtva">20%</span></td>
						<td align="right"><span id="tva"></span></td>
					</tr>
					<tr>
						<td style="border-top: none;border-left-style: none;border-bottom-style: none;" colspan="2"></td>
						<td colspan="2" align="center">Total TTC</td>
						<td align="right"><span id="totalttc"></span></td>
					</tr>
				</table>
				<!--<input type="button" onclick="ajouterligne(<?php echo $lng; ?>,<?php echo "'".$repclient->pays."'" ;?>,1)" value="<?php echo TXT_ADD; $nb++; ?>"/> -->
			</fieldset>
			<table width="100%">
				<tr>
					<td align="center">
						<input type="reset" id="annuler" value="<?php echo TXT_EFF; ?>">
					</td>
					<td>
						<input type="submit" id="ok" value="<?php echo TXT_VALID; ?>">
					</td>
					<td align="center">
						<input type="button" id="annuler" value="<?php echo TXT_RESET; ?>" onclick="javascript:history.go(-1);">
					</td>
				</tr>
			</table>
		<input type="checkbox" required> <?php echo TXT_ACCEPTER; ?>
		</form>
		<?php echo TXT_DEVIS_INFO; echo "<br>".TXT_DEVIS_INFO_2; ?>
	</fieldset>
<?php ?>