<?php
$v=1;
if($type==2){
    require('Include/fpdf.php');
    require_once('Include/Connexion.inc.php');
//    if ($lang == 'fr') {
//        include "langue/fr.inc.php";
//    } else {
//        include "langue/gb.inc.php";
//    }

}else{
    require('../fpdf.php');
    require_once('../Connexion.inc.php');
    if ($lang == 'fr') {
        include "../../langue/fr.inc.php";
    } else {
        include "../../langue/gb.inc.php";
    }

}
// le mettre au debut car plante si on declare $mysqli avant !
$pdf = new FPDF( 'P', 'mm', 'A4' );


// recuperer la langue
$lang =$_COOKIE['lang'];
$devis_fac=$type;
// charger le fichier de langue


// recuperer les données recues
if(isset($_GET['num']))
    $var_id_devis = $_GET['num'];
else
   $var_id_devis = $numresa;
    
// devis ou facture
if ($devis_fac==1){
    $Devfac=TXT_DEVISPDF1;
}else{
    $Devfac=TXT_DEVISPDF2;
    
}

// on sup les 2 cm en bas
$pdf->SetAutoPagebreak(False);
$pdf->SetMargins(0,0,0);

// RECUP DES DONNEES DU PDF
// recup donnée de l'entreprise
$sqlent="SELECT * from societe where num=1";
$result_ent = $connexion->query($sqlent);
$repent = $result_ent->fetch(PDO::FETCH_OBJ);
 
//on recupere les données des détails 
$sql = 'select devinum,qtecont,contener.*, typecontener.*,taillecontener.* FROM detaildevis join contener using(contcode) join '
        . 'typecontener on(conttype=typecode) join taillecontener on(conttaille=taillcode) where devinum=' .$var_id_devis;
$resultlignes = $connexion->query($sql);
//$replignes = $result->fetch(PDO::FETCH_OBJ);

//on recupere les données des de la resa et du client
$req_devis = 'select devis.*, client.* FROM devis join client on(devcli=idcli) where devinum=' .$var_id_devis;
$result_devis = $connexion->query($req_devis);
$repdevis = $result_devis->fetch(PDO::FETCH_OBJ);

// recherche de pays du client
$req_pays="Select * from pays where payscode='".$repdevis->pays."'";
$result_pays = $connexion->query($req_pays);
$reppays = $result_pays->fetch(PDO::FETCH_OBJ);
    
// recherche du port de départ pays et continent
$req_portdepart="select * from port join pays on(portpays=payscode) join continent on (payscont=contnum) where portcode='".$repdevis->portD."'";
$result_portdepart = $connexion->query($req_portdepart);
$repportdepart = $result_portdepart->fetch(PDO::FETCH_OBJ);

// recherche du port de départ
$req_portarrivee="select * from port join pays on(portpays=payscode) join continent on (payscont=contnum) where portcode='".$repdevis->portA."'";
$result_portarrivee = $connexion->query($req_portarrivee);
$repportarrivee = $result_portarrivee->fetch(PDO::FETCH_OBJ);

$num_page = 1; $limit_inf = 0; $limit_sup = 18;
$pdf->AddPage();
        
// logo : 60 de largeur et 35 de hauteur
if ($devis_fac==1){
    $pdf->Image('../../Images/Tholdi.png', 10, 10, 60, 35);
    $objet=$repdevis->devinum;
}else{
    $pdf->Image('Images/Tholdi.png', 10, 10, 60, 35);
    $objet=$repdevis->numfact;
}
// n° facture, date 
$num_fact = utf8_decode($Devfac." N° " .$objet  );
$pdf->SetLineWidth(0.1); $pdf->SetFillColor(192); $pdf->Rect(120, 15, 85, 8, "DF");
$pdf->SetXY( 120, 15 ); $pdf->SetFont( "Arial", "B", 12 ); $pdf->Cell( 85, 8, $num_fact, 0, 0, 'C');
        
// nom du fichier final
if ($devis_fac==1){
        $nom_file = "../../Devis/Devis_" . $repdevis->devinum . ".pdf";
}else{
        //trouver le numero de facture
        
        $nom_file = "Factures/Facture_" . $repdevis->numfact. ".pdf";
}
// date facture
$champ_date = date_create($repdevis->devdat); 
$date_fact = date_format($champ_date, 'd/m/Y');
$pdf->SetFont('Arial','',11); $pdf->SetXY( 122, 30 );
$pdf->Cell( 60, 8, "Genevillier, le " . $date_fact, 0, 0, '');
if ($devis_fac==1){    
        // observations
        $pdf->SetFont( "Arial", "BU", 10 ); 
        $pdf->SetXY( 25, 75 ) ; 
        $pdf->Cell($pdf->GetStringWidth("Observations"), 0, "Observations", 0, "L");
        $pdf->SetFont( "Arial", "", 10 ); 
        $pdf->SetXY( 25, 78 ) ; 
        $pdf->MultiCell(190, 4, TXT_DEVISPDF3, 0, "L");
}

// adr fact du client

$pdf->SetFont('Arial','B',11); 
$x = 110 ; 
$y = 50;
$pdf->SetXY( $x, $y ); 
$pdf->Cell( 100, 8, $repdevis->nom, 0, 0, ''); 
$y += 4;
$pdf->SetXY( $x, $y ); 
$pdf->Cell( 100, 8, $repdevis->adresse, 0, 0, ''); 
$y += 4;
$pdf->SetXY( $x, $y ); 
$pdf->Cell( 100, 8, $repdevis->	CP .' '.strtoupper ($repdevis->ville) , 0, 0, ''); 
$y += 4;
$pdf->SetXY( $x, $y ); 
      
if($repdevis->pays!="FRF"){
    if ($lang == 'fr') {
            $pdf->Cell( 100, 8,strtoupper ($reppays->paysnomfr) , 0, 0, '');
    }else{
            $pdf->Cell( 100, 8,strtoupper ($reppays->paysnomGB) , 0, 0, '');
    }
}
$pdf->SetFont( "Arial", "BU", 10 );
$pdf->SetXY( 25, 53 ) ;
$pdf->Cell($pdf->GetStringWidth(TXT_DEVISPDF4), 0, utf8_decode(TXT_DEVISPDF4), 0, "L");
$pdf->SetFont( "Arial", "", 10 );
$pdf->SetXY( 25, 55 ) ; 
//$pdf->MultiCell(180, 4,$repdevis->clinumtva , 0, "L");
$pdf->SetFont( "Arial", "BU", 10 );
$pdf->SetXY( 25, 62 ) ;
$pdf->Cell($pdf->GetStringWidth(TXT_DEVISPDF4BIS), 0, utf8_decode(TXT_DEVISPDF4BIS), 0, "L");
$pdf->SetFont( "Arial", "", 10 );
$pdf->SetXY( 25, 64 ) ; 
$pdf->MultiCell(180, 4,$repent->numintra , 0, "L");       
// ***********************
// le cadre des articles
// ***********************
// cadre 

$pdf->SetLineWidth(0.1); 
$pdf->Rect(5, 95, 200, 40, "D");
        
// cadre titre des colonnes
$pdf->Line(5, 105, 205, 105);
        
// les traits verticaux colonnes
$pdf->Line(100, 95, 100, 135); 

// titre 
$pdf->SetXY( 1, 93 ); 
$pdf->SetFont('Arial','B',14); 
$pdf->Cell(100, 16, "DEPART", 0, 0, 'C');
$pdf->SetXY( 100, 93 ); 
$pdf->SetFont('Arial','B',14); 
$pdf->Cell(100, 16, "ARRIVEE", 0, 0, 'C');
         
// positionner les info de depart
$pdf->SetXY( 14, 103 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14, TXT_RE5.":", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(10, 14,$repportdepart->portnom.' ('.$repportdepart->portcode.')'  , 0, 0, 'l');
$pdf->SetXY( 14, 109 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14, TXT_RE4.": ", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);

if ($lang == 'fr') { 
    $pdf->Cell(10, 14,utf8_decode($repportdepart->paysnomfr) , 0, 0, 'l');
}else{
    $pdf->Cell(10, 14,utf8_decode($repportdepart->paysnomgb) , 0, 0, 'l');
}
$pdf->SetXY( 14, 115 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14, TXT_RE3.": ", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);

if ($lang == 'fr') { 
        $pdf->Cell(10, 14,utf8_encode($repportdepart->connomfr) , 0, 0, 'l');
}else{
        $pdf->Cell(10, 14,utf8_encode($repportdepart->connomgb) , 0, 0, 'l');
}
$pdf->SetXY( 14, 121 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14, utf8_decode(TXT_RE6).": ", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);
         
$date = new DateTime($repdevis->dateDpt);
if ($lang == 'fr') { 
    $pdf->Cell(10, 14,$date->format('d/m/Y'), 0, 0, 'l');
}else{
    $pdf->Cell(10, 14,$date->format('y-m-d'), 0, 0, 'l');
}
         
// positionner les info arrivée
$pdf->SetXY( 114, 103 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14, utf8_decode(TXT_RE5).":", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(10, 14,$repportarrivee->portnom.' ('.$repportarrivee->portcode.')' , 0, 0, 'l');
$pdf->SetXY( 114, 109 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14, utf8_decode(TXT_RE4).": ", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);
if ($lang == 'fr') { 
    $pdf->Cell(10, 14,utf8_decode($repportarrivee->paysnomfr) , 0, 0, 'l');
}else{
    $pdf->Cell(10, 14,utf8_decode($repportarrivee->paysnomgb) , 0, 0, 'l');
}
$pdf->SetXY( 114, 115 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14, TXT_RE3.": ", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);
if ($lang == 'fr') { 
        $pdf->Cell(10, 14,utf8_encode($repportarrivee->connomfr) , 0, 0, 'l');
}else{
        $pdf->Cell(10, 14,utf8_encode($repportarrivee->connomgb) , 0, 0, 'l');
}
$pdf->SetXY( 114, 121 ); 
$pdf->SetFont('Arial','',12); 
$pdf->Cell(25, 14,utf8_decode( TXT_RE6).": ", 0, 0, 'l');
$pdf->SetFont('Arial','B',12);
         
$date1 = new DateTime($repdevis->dateArv);
if ($lang == 'fr') { 
    $pdf->Cell(10, 14,$date1->format('d/m/Y'), 0, 0, 'l');
}else{
    $pdf->Cell(10, 14,$date1->format('y-m-d'), 0, 0, 'l');
}

// les conteneurs
$pdf->SetLineWidth(0.1); 
$pdf->Rect(5, 140, 200, 100, "D");         

// cadre titre des colonnes
$pdf->Line(5, 150, 205, 150);
$pdf->SetFont('Arial','B',14);
$pdf->SetXY( 5, 139);
$pdf->Cell(0, 14, strtoupper (utf8_decode(TXT_DEVISPDF5)), 0, 0, 'C'); 
          
// titre colonne
$pdf->Line(5, 160, 205, 160);
$pdf->SetXY( 15, 150 ); 
$pdf->SetFont('Arial','B',10); 
$pdf->Cell( 40, 10, strtoupper (utf8_decode(TXT_CONT)), 0, 0, 'C');
$pdf->Line(65, 150, 65, 240);
        
$pdf->SetXY( 70, 150 ); 
$pdf->SetFont('Arial','B',10); 
$pdf->Cell( 40, 10, strtoupper (utf8_decode(TXT_SIZE)), 0, 0, 'C');
$pdf->Line(115, 150, 115, 240);
         
$pdf->SetXY( 115, 150 ); 
$pdf->SetFont('Arial','B',10); 
$pdf->Cell( 30, 10, strtoupper (utf8_decode(TXT_DEVISPDF6)), 0, 0, 'C');
$pdf->Line(145, 150, 145, 240);
         
$pdf->SetXY( 150, 150 ); 
$pdf->SetFont('Arial','B',10); 
$pdf->Cell(15, 10, strtoupper (utf8_decode(TXT_DEVISPDF7)), 0, 0, 'C');
$pdf->Line(170, 150, 170, 240);
          
$pdf->SetXY( 170, 150 ); 
$pdf->SetFont('Arial','B',10); 
$pdf->Cell(0, 10, strtoupper (utf8_decode(TXT_DEVISPDF8)), 0, 0, 'C');   

$poy=165;
//detail du devis
$total=0;
 while(($replignes = $resultlignes->fetch(PDO::FETCH_OBJ))){
    $pdf->SetXY( 5, $poy);
    $pdf->SetFont('Arial','',10);
    $pdf->Cell( 40, 10, utf8_decode($replignes->typelibel), 0, 0, 'l');
    $pdf->SetXY( 70, $poy);
    $pdf->Cell( 30, 10, $replignes->taillong."' ".$replignes->taillarg."' ".$replignes->taillhaut."'", 0, 0, 'l');
    $pdf->SetXY( 115, $poy);
    $pdf->Cell( 28, 10, $replignes->qtecont, 0, 0, 'R');
    if($repdevis->duree<90){
        $prix=$replignes->conttarifjour;
    } else {
        if($repdevis->duree<360){
            $prix=$replignes->conttariftrim;
        }else{
            $prix=$replignes->conttarifan;
        }
    }
   $pdf->SetXY( 155, $poy);
   $pdf->Cell(15, 10, number_format($prix, 2, ',', ' ')." ".chr(128), 0, 0, 'R');
   $tot=$prix*$repdevis->duree*$replignes->qtecont;
    $pdf->SetXY( 170, $poy ); 
    $pdf->Cell(33, 10, number_format($tot, 2, ',', ' ')." ".chr(128), 0, 0, 'R');
    $total+=$tot;
    $poy+=6;
}    

// le detail des totaux, demarre a 221 après le cadre des totaux
$pdf->SetXY( 115, 240 ); 
$pdf->SetFont('Arial','B',10); 
$pdf->Cell( 55, 10, TXT_DEVISPDF9, 1, 0, 'L'); 
$pdf->SetXY( 170, 240);
$pdf->Cell( 35, 10, number_format($total, 2, ',', ' ')." ".chr(128), 1, 0, 'R'); 
$pdf->SetXY( 115, 250 );
$pdf->Cell( 30, 10, TXT_DEVISPDF10, 1, 0, 'L');
$tauxtva= 20;
$tva=$tauxtva*$total/100;
$TTC=$total+$tva;
$tauxtva.= " %";

$pdf->Cell( 25, 10, $tauxtva, 1, 0, 'R');
if($tva==0){
    $pdf->Cell( 35, 10," ", 1, 0, 'R');
}else{
    $pdf->Cell( 35, 10, number_format($tva, 2, ',', ' ')." ".chr(128), 1,0, 'R');
}
$pdf->SetXY( 115, 260 );
$pdf->Cell( 55, 10, TXT_DEVISPDF9, 1, 0, 'L',true);
 $pdf->Cell( 35, 10, number_format($TTC, 2, ',', ' ')." ".chr(128), 1,0, 'R');
        // **************************
        // pied de page
        // **************************
         $y1 = 270;
        //Positionnement en bas et tout centrer
        $pdf->SetXY( 1, $y1 ); $pdf->SetFont('Arial','B',10);
        
        
        $pdf->SetFont('Arial','',10);
        
        $pdf->SetXY( 1, $y1 + 4 ); 
        $pdf->Cell( $pdf->GetPageWidth(), 5, "IBAN : ".$repent->IBAN, 0, 0, 'C');
        //$pdf->Cell( $pdf->GetPageWidth(), 5, "NOM SOCIETE", 0, 0, 'C');
        
        $pdf->SetXY( 1, $y1 + 8 );
        $pdf->Cell( $pdf->GetPageWidth(), 5, utf8_decode($repent->adresse." - ".$repent->adresse2." - ".$repent->cp." ".strtoupper ($repent->ville)), 0, 0, 'C');

        $pdf->SetXY( 1, $y1 + 12 );
        $pdf->Cell( $pdf->GetPageWidth(), 5, "Tel : ".$repent->tel." - Mail : ".$repent->mel, 0, 0, 'C');

        $pdf->SetXY( 1, $y1 + 16 );
        $pdf->Cell( $pdf->GetPageWidth(), 5, "www.tholdi.fr", 0, 0, 'C');
        
       

   // $pdf->Output("I");
        $pdf->Close();
        
    $pdf->Output("F", $nom_file);
    
?>
