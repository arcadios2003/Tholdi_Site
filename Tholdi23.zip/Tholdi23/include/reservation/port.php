<?php
// Requète pour les port de la page de réservation

require_once('../Connexion.inc.php');
$idr1 = isset($_GET['idr1']) ? $_GET['idr1'] : false;
$nb = $_GET['nb1'];
$lng = $_GET['lng1'];
if(false !== $idr1) {
	$sql2 = "SELECT portcode, portnom AS nom".
			" FROM port".
			" WHERE portpays = '". $idr1 . "'".
			" ORDER BY portnom;";
	$resport = $connexion->query($sql2);
	$nd = 0;
	$code_port = array();
	$nom_port = array();

	while(false != ($repport = $resport->fetch(PDO::FETCH_OBJ))){
		$code_port[] = $repport->portcode;
		$nom_port[] = $repport->nom;
		$nd++;
	}
	if($lng == 1){
		$tt = "Choisir le port";
	} else {
		$tt = "Choose Harbort";
	}
	$listeP = "";
	$listeP .= '<select required name="port'.$nb.'" id="port'.$nb.'"> <option value =-1>'.$tt.'</option>';
	for($d = 0; $d < $nd; $d++) {
		$listeP .= '<option value="'. $code_port[$d].'">'.
				htmlentities(utf8_encode($nom_port[$d])). '('. $code_port[$d]. ') </option>';
	}
	$listeP .= '</select'."\n";
	echo ($listeP);
} else {
	echo ("<p>Une erreur s'est produite. La région sélectionnée comporte une donnée invalide. </p> \n");
}
?>