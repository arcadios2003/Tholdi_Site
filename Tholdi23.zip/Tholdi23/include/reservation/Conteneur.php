<?php
$v = 1;
require_once('../Connexion.inc.php');

$idr = isset($_GET['idr']) ? $_GET['idr'] : false;
$lng = $_GET['lng'];
$prix = $_GET['prix'];
if (false !== $idr) {
	$sql2 = "SELECT * FROM CONTENER WHERE contcode = '".$idr."'";

	$rescont = $connexion->query($sql2);
	$repcont = $rescont->fetch(PDO::FETCH_OBJ);

	switch ($prix){
		case 'j' : $rp=$repcont->conttarifjour;
			break;
		case 't' : $rp=$repcont->conttariftrim;
			break;
		case 'a' : $rp=$repcont->conttarifan;
			break;
	}

	echo($rp);
} else {
	if($lng==1) {
		echo("<p>Une erreur s'est produite. La région sélectionnée comporte une donnée invalide.</p> \n");
	} else {
		echo ("<p> An error has ocurred. The selected region has an invalid data. </p> \n");
	}
}
?>