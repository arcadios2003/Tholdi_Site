<?php
//////////

$mail = $repdevis->climel; // Déclaration de l'adresse de destination.
if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn).[a-z]{2,4}$#", $mail)) // On filtre les serveurs qui présentent des bogues.
{
	$passage_ligne = "\r\n";
}
else
{
	$passage_ligne = "\n";
}


//=====Lecture et mise en forme de la pièce jointe.
if($type==1){
    $file_name ="Devis_".$repdevis->resanum . ".pdf";
    $file_type = filetype($fichier);
    $file_size = filesize($fichier);
    $fichier=file_get_contents("../../Devis/".$file_name );
    //=====Déclaration des messages au format texte et au format HTML.
    if($_GET['modif']==1){
        $message_txt =TXT_MAIL2.",\n".utf8_decode(TXT_MAIL13)."THOLDI\n";
        $message_html = "<html><head></head><body><b>".TXT_MAIL12."</b>,<BR>". utf8_decode(TXT_MAIL13)."THOLDI <BR></body></html>";
    }else{
        $message_txt =TXT_MAIL2.",\n".utf8_decode(TXT_MOFIRESA6)."\n".utf8_decode(TXT_MOFIRESA7);
        $message_html = "<html><head></head><body><b>".TXT_MAIL12."</b>,<BR>".utf8_decode(TXT_MOFIRESA6)."<br>".utf8_decode(TXT_MOFIRESA7)."</body></html>";
    }//========== 
}else{
    $file_name ="Facture_".$repdevis->numfac . ".pdf";
    $file_type = filetype($fichier);
    $file_size = filesize($fichier);
    $fichier=file_get_contents("Factures/".$file_name );
    $message_txt =TXT_MAIL2.",\n".utf8_decode(TXT_MAIL14)."THOLDI\n";
    $message_html = "<html><head></head><body><b>".TXT_MAIL12."</b>,<BR>"
                .utf8_decode(TXT_MAIL14)."<br>".utf8_decode(TXT_MAIL15)."<br>".utf8_decode(TXT_MAIL16)."<br>";  
}
$content = chunk_split(base64_encode($fichier));
fclose($fichier);


//=====Création de la boundary
$boundary = "-----=".md5(rand());
//==========
 
//=====Définition du sujet.
$sujet = TXT_MAIL1;
//=========
 
 
//=====Création du header de l'e-mail.
$header = "From: \"Reservation THOLDI\"<reservation@tholdi.com>".$passage_ligne;
$header.= "Reply-to: \"Reservation THOLDI\" <reservation@tholdi.com>".$passage_ligne;
$header.= "MIME-Version: 1.0".$passage_ligne;
$header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"$boundary\"".$passage_ligne;
//==========
 
//=====Création du message.
$message = $passage_ligne."--".$boundary.$passage_ligne;
$message.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"$boundary_alt\"".$passage_ligne;
$message.= $passage_ligne."--".$boundary_alt.$passage_ligne;
//=====Ajout du message au format texte.
$message.= "Content-Type: text/plain; charset=\"ISO-8859-1\"".$passage_ligne;
$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
$message.= $passage_ligne.$message_txt.$passage_ligne;
//==========
 
$message.= $passage_ligne."--".$boundary_alt.$passage_ligne;
 
//=====Ajout du message au format HTML.
$message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
$message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
$message.= $passage_ligne.$message_html.$passage_ligne;
//==========
 
//=====On ferme la boundary alternative.
$message.= $passage_ligne."--".$boundary_alt."--".$passage_ligne;
//==========
 
 
 
$message.= $passage_ligne."--".$boundary.$passage_ligne;
 
//=====Ajout de la pièce jointe.
$message.= "Content-Type: ".$file_type."; name=\"".$file_name."\"".$passage_ligne;
$message.= "Content-Transfer-Encoding: base64".$passage_ligne;
$message.= "Content-Disposition: attachment; filename=\"".$file_name."\"".$passage_ligne;
$message.= $passage_ligne.$content.$passage_ligne.$passage_ligne;
$message.= $passage_ligne."--".$boundary."--".$passage_ligne; 
//========== 
//=====Envoi de l'e-mail.
mail($mail,$sujet,$message,$header);
 
//==========
?>