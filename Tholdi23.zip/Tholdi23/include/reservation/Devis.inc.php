<?php
require_once('include/Connexion.inc.php');
include('MenuReservation.inc.php');

if(!isset($_COOKIE['id'])) {
	header('location:../index.php?val=4');
}
$lang = $_COOKIE['lang'];
$Cli = $_COOKIE['id'];

$sql_devi = "SELECT devis.*, D.portnom as portDepart, A.portnom as portArive, devetat, etatlibel FROM devis JOIN port D on (portD=D.portcode) JOIN port A on (portA = A.portcode) JOIN etat ON (devetat = numetat) WHERE devcli=".$Cli;
$reqdevi = $connexion->query($sql_devi);

?>
<div align="center">
	<br><?php echo TXT_VALIDER0; ?>
</div>
<br>
<fieldset>
	<legend> <?php echo TXT_VALIDER1; ?></legend>
	<!--Redirection vers la page pour valider la réservation-->
	<form name="resa" action="index.php?val=10" method="post">
	<input name="lang" hidden value="<?php echo $lang; ?>">
	<br>
	<table border="1" width="100%">
		<tr>
			<td align="center" rowspan="2"></td>
			<td align="center" rowspan="2"><?php echo TXT_VALIDER2;?></td>
			<td align="center" rowspan="2"><?php echo TXT_VALIDER3;?></td>
			<td align="center" colspan="2"><?php echo TXT_RE5;?></td>
			<td align="center" colspan="2"><?php echo TXT_RE6;?></td>
			<td align="center" rowspan="2"><?php echo TXT_VALIDER6;?></td>
		</tr>
		<tr>
			<td align="center"><?php echo TXT_D ;?></td>
			<td align="center"><?php echo TXT_A ;?></td>
			<td align="center"><?php echo TXT_D ;?></td>
			<td align="center"><?php echo TXT_A ;?></td>
		</tr>

<?php
	if($reqdevi->rowCount()!=0){
		while ($repdevi = $reqdevi->fetch(PDO::FETCH_OBJ)){
?>
		<tr>
			<td align="center"><input type="radio" name="resa" value="<?php echo $repdevi->devinum."-".$repdevi->devetat;?>"> </td>
			<td align="center"><a href="Devis/Devis_<?php echo $repdevi->devinum; ?>.pdf" target="_blank"><?php echo $repdevi->devinum; ?> </a> </td>
			<?php $dateresa = new DateTime($repdevi->devdat);?>
			<td align="center"><?php echo $dateresa->format('d/m/Y');?></td>
			<td align="center"><?php echo $repdevi->portDepart."<br>(".$repdevi->portD.")";?></td>
			<td align="center"><?php echo $repdevi->portArive."<br>(".$repdevi->portA.")";?></td>
			<?php $datedep = new DateTime($repdevi->dateDpt);?>
			<td align="center"><?php echo $datedep->format('d/m/Y');?></td>
			<?php $datearv = new DateTime($repdevi->dateArv);?>
			<td align="center"><?php echo $datearv->format('d/m/Y');?></td>
			<td align="center"><?php echo utf8_encode($repdevi->etatlibel); ?></td>
		</tr>

<?php
		}
?>
	</table><table width="100%">
		<tr>
			<td colspan="2" align="center"></td>
			<td colspan="2" align="center"><input type="hidden" name="Val" value="0">
				<input type="submit" id="ok" value="<?php echo TXT_VALID;?>" onmouseover="document.forms['resa'].Val.value='0'"</td>
			<td colspan="2" align="center"><input type="submit" id="ok" value="<?php echo TXT_VALIDER4;?>" onmouseover="document.forms['resa'].Val.value='1'"</td>
			<td colspan="2" align="center"><input type="submit" id="ok" value="<?php echo TXT_VALIDER5;?>" onmouseover="document.forms['resa'].Val.value='2'"</td>
<?php
	}else{
		echo "<tr><td colspan='7'>Aucun devis</td><tr>";
	}
?>


	</table>
</fieldset>