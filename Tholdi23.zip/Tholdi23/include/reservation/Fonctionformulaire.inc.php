<SCRIPT LANGUAGE="JavaScript">

var nbjour=1;

function surligne(champ, erreur)
{
   if(erreur)
      champ.style.backgroundColor = "#fba";
   else
      champ.style.backgroundColor = "";
}
function verifnom(champ)
{
   if(champ.value.length < 2 || champ.value.length > 25)
   {
      surligne(champ, true);
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}
function verifMail(champ)
{
   var regex = /^[a-zA-Z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$/;
   if(!regex.test(champ.value))
   {
      surligne(champ, true);
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
 }
function verifPays(champ){
   
    if (champ.value!=='0'){
       surligne(champ, false);
      return true;
    }else
   {
       surligne(champ, true);
      return false; 
      
   }
} 
function verifpass(champ1,champ2){
   var c1 = true;
   var c2 =true;
        if(champ1.value.length < 6 || champ1.value.length > 10)
   {
      surligne(champ1, true);
      c1=false;
   }else
       surligne(champ1, false);
   if(champ2.value.length < 6 || champ2.value.length > 10)
   {
      surligne(champ2, true);
      c2=false;
   }else
       surligne(champ2, false);
   
   if(c1===false || c2=== false){
       return false;
   }else
   {
       if (champ1.value===champ2.value){
           surligne(champ2, false);
           return true;
           
       }else{
            surligne(champ1, true);
            surligne(champ2, true);
           return false;
       }
   }
   
   
}
function verifForm1(f)
{
   var NomOk = verifnom(f.Nom);
   var AdrsOk = verifnom(f.Adresse);
   var CPOk = verifnom(f.Cp); 
   var VilleOk = verifnom(f.Ville);
   var MailOk = verifMail(f.Mel);
   var PaysOk = verifPays(f.Pays);
   var LoginOk = verifnom(f.Login);
   var PassOk = verifpass(f.Pas1,f.Pas2);
 
   if(NomOk && AdrsOk &&  CPOk && MailOk && VilleOk && PaysOk && LoginOk && PassOk)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}
nb=1;

function ajouterligne(lg,lpays,lue,n){
   
   if(nb<n){
       nb=n;
   }
        
    var table = document.getElementById("tableresa");
    var row = table.insertRow(nb+1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    cell4.align="right";
    cell5.align="right";
   var liste="";
   var tt='typeconteneur-'+nb;
    var nbliste = document.getElementById(tt).options.length;
   for (var i = 0; i<nbliste ;i++) {
      liste=liste + "<option value='" + i + "'>" + document.getElementById(tt).options[i].text + "</option>";
   }
   nb++;
    cell1.innerHTML = "<select required name='typeconteneur-" + nb + "'  id='typeconteneur-" + nb + "' onchange='gettaille(this.value," + nb +"," + lg + ")' required>" + liste + "</select>";
    cell2.innerHTML = "<span id='taille" + nb + "'></span>";
    
    cell3.innerHTML = '<input min="0" type="number" name="qte-' + nb + '" id="qte-'+ nb +'" onblur="getprix('+nb+','+lg+',\''+lpays+'\','+lue+')";>';
    cell4.innerHTML = "<span id='prix" + nb + "'></span>";
    cell5.innerHTML = "<span hidden id='total" + nb + "'></span><span id='tot" + nb + "'></span>";
}
function verifVal(champ){
    if(champ.value!=-1){
         surligne(champ, false);
         return true;
    }else{
        surligne(champ, true);
         return false;
     
    }
    
}
//----
function estdate(uneDate){
    // Cette fonction vérifie le format JJ/MM/AAAA saisi et la validité de la date.
      // Le séparateur est défini dans la variable separateur
      var amin=2017; // année mini
      var amax=2025; // année maxi
      var separateur="/"; // separateur entre jour/mois/annee
      var d= uneDate.value;
      var j=(d.substring(0,2));
      var m=(d.substring(3,5));
      var a=(d.substring(6));
      var ok=1;
      if ( ((isNaN(j))||(j<1)||(j>31)) && (ok==1) ) {
         alert("Le jour n'est pas correct."); ok=0;
      }
      if ( ((isNaN(m))||(m<1)||(m>12)) && (ok==1) ) {
         alert("Le mois n'est pas correct."); ok=0;
      }
      if ( ((isNaN(a))||(a<amin)||(a>amax)) && (ok==1) ) {
         alert("L'année n'est pas correcte."); ok=0;
      }
      if ( ((d.substring(2,3)!=separateur)||(d.substring(5,6)!=separateur)) && (ok==1) ) {
         alert("Les séparateurs doivent être des "+separateur); ok=0;
      }
      if (ok==1) {
         var d2=new Date(a,m-1,j);
         j2=d2.getDate();
         m2=d2.getMonth()+1;
         a2=d2.getFullYear();
         if (a2<=100) {a2=1900+a2}
         if ( (j!=j2)||(m!=m2)||(a!=a2) ) {
            alert("La date "+d+" n'existe pas !");
            ok=0;
         }
      }
      if (ok==0){
         surligne(uneDate, true); 
        return false;
     }else{
         surligne(uneDate, false);
         return true;
     }
   }

function verifDate(uneDate1,uneDate2){
    var date1=uneDate1.value;
var date2=uneDate2.value;


var date1 = date1.split('/').reverse().join('');
var date2 = date2.split('/').reverse().join('');


if(date1>date2)
{
   surligne(uneDate1, true);
   surligne(uneDate2, true);
alert("erreur dans les dates l'arrive plus petite que le depart");
return false;
}else{
    surligne(uneDate1, false);
   surligne(uneDate2,false);
    return true;
}
    
}

 
//--

function verifForm2(f)
{
   var ok=true;
    var contDok = verifVal(f.continentD);
  var contAok = verifVal(f.continentA);
  if(contDok){
      var paysDok = verifVal(f.paysD);
      if(paysDok){
         var portDok = verifVal(f.port1);
         if(!portDok){
               ok=false;
          }
      }else{
           ok=false;
      }
  }else{
      ok=false;
  }
  if (contAok){
      var paysAok = verifVal(f.paysA);
      if(paysAok){
          var portAok = verifVal(f.port2);
          
          if(!portAok){
               ok=false;
          }
    }
 }else{
     ok=false;
 }
 
if(!estdate(f.dateD)){
    ok=false;
}
if(!estdate(f.dateA)){
    ok=false;
}

if (!verifDate(f.dateD,f.dateA)){
    ok=false;
    
}

 
   if(ok){
       return true;
   }
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

 </SCRIPT>
 
 
 
 
