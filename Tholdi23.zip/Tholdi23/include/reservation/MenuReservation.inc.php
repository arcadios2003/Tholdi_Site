<ul class="menu-vertical">
	<li class="mv-item">
		<a href="index.php?val=8"><?php echo TXT_RESERVER; ?></a>
	</li>
	<li class="mv-item">
		<a href="index.php?val=9"><?php echo TXT_DEVIS; ?></a>
	</li>
	<li class="mv-item">
		<a href="index.php?val=12"><?php echo TXT_FACTURE; ?></a>
	</li>
	<li class="mv-item">
		<a href="index.php?val=950"><?php echo TXT_DECONNEXION; ?></a>
	</li>
</ul>