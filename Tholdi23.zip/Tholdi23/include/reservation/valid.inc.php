<?php
require_once('include/Connexion.inc.php');
include('MenuReservation.inc.php');
?>

<div align="center">
	<h3><?php echo TXT_RES_VAL; ?></h3>
</div>