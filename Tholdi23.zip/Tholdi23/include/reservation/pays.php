<?php
$v = 1;
require_once('../Connexion.inc.php');
$idr = isset($_GET['idr']) ? $_GET['idr'] : false;
$nb = isset($_GET['nb']) ? $_GET['nb'] : false;
$lng = $_GET['lng'];

if(false !== $idr) {
	if($lng == 1) {
		$sql2 = "SELECT DISTINCT payscode, paysnomfr AS nom".
				" FROM pays JOIN port on (payscode = portpays)".
				" WHERE payscont = ".$idr.
				" ORDER BY paysnomfr;";
	} else {
		$sql2 = "SELECT DISTINCT payscode, paysnomgb AS nom".
				" FROM pays JOIN port on (payscode = portpays)".
				" WHERE payscont = ".$idr.
				" ORDER BY paysnomgb;";
	}
	$respays = $connexion->query($sql2);
	$nd = 0;
	$code_pays = array();
	$nom_pays = array();

	while(false != ($reppays = $respays->fetch(PDO::FETCH_OBJ))) {
		$code_pays[] = $reppays->payscode;
		$nom_pays[] = $reppays->nom;
		$nd++;
	}
	$liste = "";
	if($nb==1){
		if($lng==1){
			$liste .= "<select required name='paysD' id='paysD' onchange='getPort(this.value,1,1);'><option value=-1>Choisir le pays</option> \n";
		} else {
			$liste .= "<select required name='paysD' id='paysD' onchange='getPort(this.value,1,2);'><option value=-1>Choose your country</option> \n";
		}
	} else {
		if($lng==1){
			$liste .="<select required name='paysA' id='paysA' onchange='getPort(this.value,2,1);'><option value =-1>Choisir le pays</option>\n";
		} else {
			$liste .="<select required name='paysA' id='paysA' onchange='getPort(this.value,2,2);'><option value =-1>Choose your country</option>\n";
		}
	}

	for ($d = 0; $d < $nd; $d++) {
		$liste .='<option value ="'.$code_pays[$d].'">'.
		utf8_encode($nom_pays[$d]).' ('. $code_pays[$d].') </option>'."\n";
	}
	$liste .= '</select>'."\n";
	echo($liste);
} else {
	if($lng='fr'){
		echo("<p>Une erreur s'est produite. La région sélectionnéee comporte une donnée invalide.</p>\n");
	} else {
		echo ("<p>An error has ocurred. The selected region has an invalid data.</p>\n");
	}
}
?>