<?php
	$dns = 'mysql:host=localhost;dbname=tholdi';
	$utilisateur = 'root';
	$mdp = '';
?>