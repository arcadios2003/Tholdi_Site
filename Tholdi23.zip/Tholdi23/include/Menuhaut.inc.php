<?php session_start(); ?>

<div id="menuhaut1">
	<ul>
		<li <?php if (!isset($_GET['val']) or $_GET ['val'] == 0)
			echo 'class="active"'; ?>
			><a href="index.php?val=0"><?php echo TXT_ACUEIL_INDEX; ?></a></li>
		<li <?php if (isset($_GET['val']) and $_GET ['val'] == 1)
			echo 'class="active"'; ?>
			><a href="index.php?val=1"><?php echo TXT_CONTENEUR; ?></a></li>
		<li <?php if (isset($_GET['val']) and $_GET ['val'] == 2)
			echo 'class="active"'; ?>
			><a href="index.php?val=2"><?php echo TXT_SERVICE; ?></a></li>
		<li <?php if (isset($_GET['val']) and $_GET ['val'] == 3)
			echo 'class="active"'; ?>
			><a href="index.php?val=3"><?php echo TXT_TARIFS; ?></a></li>
		<?php if(!isset($_COOKIE['id'])){?><li <?php if (isset($_GET['val']) and $_GET ['val'] == 4 )
			echo 'class="active"'; ?>
			><a href="index.php?val=4"><?php echo TXT_CONNEXION; ?></a></li> <?php } else { ?>
		<li <?php if (isset($_GET['val']) and $_GET ['val'] == 7 and isset($_COOKIE['id']))
			echo 'class="active"'; ?>
			><a href="index.php?val=7"><?php echo TXT_RESERVATION; ?></a></li> <?php } ?>
	</ul>
</div>