<?php

	require_once('Connexion.inc.php');
	$str_requete2 = "SELECT conttype, count(*) AS nb FROM CONTENER JOIN TAILLECONTENER ON (conttaille=taillcode) GROUP BY conttype ORDER BY conttype";
	$result2 = $connexion->query($str_requete2);

	$str_requete = "SELECT * FROM CONTENER JOIN typecontener ON (conttype=typecode) JOIN TAILLECONTENER ON (conttaille=taillcode) ORDER BY conttype,conttaille";
	$result = $connexion->query($str_requete);

?>

<br>
<table align="center" width="85%" border="2">
	<th colspan="6"> <?php echo TXT_TITRETARIFS; ?></th>
	<tr>
		<td align="center" rowspan="2"><?php echo TXT_TYPE; ?></td>
		<td rowspan="2" align="center"><?php echo TXT_IMAGE; ?></td>
		<td rowspan="2" align="center"><?php echo TXT_TAILLES; ?></td>
		<td colspan="3" align="center"><?php echo TXT_TITRETARIFS; ?></td>
	</tr>
	<tr>
		<td align="center"><?php echo TXT_TARIFJOUR; ?></td>
		<td align="center"><?php echo TXT_TARIFTRIM; ?></td>
		<td align="center"><?php echo TXT_TARIFAN; ?></td>
	</tr>

<?php
	$typecode =-1;
	while(($reponses = $result->fetch(PDO::FETCH_OBJ))){
		if($typecode != $reponses->typecode){
			$reponses2 = $result2->fetch(PDO::FETCH_OBJ);
		echo "<tr><td align='center' rowspan='".$reponses2->nb."'>"
			.$reponses->typelibel."</td><td align='center' rowspan='"
			.$reponses2->nb."'><img src='Imgbase/conteneur/"
			.$reponses->phototype."'/></td>";
		$typecode=$reponses->typecode;
		}
		echo '<td align="center">'.$reponses->taillong.'\''
			.$reponses->taillarg.'\''.$reponses->taillhaut.'</td>';
		echo '</td> <td align="right">';
		echo number_format($reponses->conttarifjour,2,',',' ') 
			.'€ </td><td align = "right">';
		echo number_format($reponses->conttariftrim*90,2,',',' ') 
			.'€ (';
		echo number_format($reponses->conttariftrim,2,',',' ') 
			.'€/j) </td><td align = "right">';
		echo number_format($reponses->conttarifan*360,2,',',' ') 
			.'€ (';
		echo number_format($reponses->conttarifan,2,',',' ') 
			.'€/j </td></tr>';
	}
?>
</table>