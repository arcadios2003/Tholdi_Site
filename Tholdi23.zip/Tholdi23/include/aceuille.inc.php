<br>
<table>
	<tr><td colspan="2"><?php echo TXT_PRESENTATION  ?></td></tr>
	<tr><td colspan="2"><?php echo TXT_PRESENTATION2 ?></td></tr>
	<tr><td colspan="2"><?php echo TXT_PRESENTATION3 ?></td></tr>
</table>
<br><br>
<div align="center">
	<div id="slider">
		<figure>
			<img src="Images/PortGennevilliers.jpg" alt>
			<img src="Images/Hambourg.jpeg" alt>
			<img src="Images/marseille.jpg" alt>
			<img src="Images/Havre.jpg" alt>
			<img src="Images/portgennevilliers.jpg" alt>
		</figure>
	</div>
</div>